package ua.helper.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class AssistantService : Service() {

    companion object {
        const val ACTION_START = "ua.helper.assistant.START"
        const val ACTION_STOP = "ua.helper.assistant.STOP"
        const val ACTION_LISTEN = "ua.helper.assistant.LISTEN"
        const val ACTION_RELOAD = "ua.helper.assistant.RELOAD"
        const val ACTION_TEXT = "ua.helper.assistant.TEXT"
        const val ACTION_SPEAK = "ua.helper.assistant.SPEAK"
        const val ACTION_INCOMING = "ua.helper.assistant.INCOMING"
        const val ACTION_STOP_RECORD = "ua.helper.assistant.STOP_RECORD"
        const val ACTION_UNMUTE = "ua.helper.assistant.UNMUTE"

        private const val CHANNEL_ID = "assistant_service"
        private const val NOTIF_ID = 1

        @Volatile
        var running = false

        /** off, idle, wake, command, busy: для індикатора в інтерфейсі */
        @Volatile
        var mode = "off"
        var stateListener: (() -> Unit)? = null

        @JvmName("changeMode")
        fun setMode(m: String) {
            mode = m
            stateListener?.invoke()
        }

        val log = ArrayList<String>()
        var logListener: ((String) -> Unit)? = null

        fun addLog(line: String) {
            synchronized(log) {
                log.add(line)
                while (log.size > 60) log.removeAt(0)
            }
            logListener?.invoke(line)
        }
    }

    private val uk = Locale("uk", "UA")
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var storage: Storage
    private lateinit var ai: AiClient
    private lateinit var processor: CommandProcessor
    private lateinit var skills: Skills

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsUkOk = false
    private var warnedTts = false
    private val speakCallbacks = HashMap<String, () -> Unit>()
    private var utteranceCounter = 0

    private var recognizer: SpeechRecognizer? = null
    private var listeningForCommand = false
    private var busy = false
    private var stopped = false
    private var foregroundStarted = false
    private var lastNotifText = ""
    private var wakeLock: PowerManager.WakeLock? = null
    private var sessionId = 0
    private var sessionHandled = false
    private var segmentedActive = false
    private var lastRmsArm = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        storage = Storage(this)
        ai = AiClient(storage)
        processor = CommandProcessor(this, storage)
        skills = Skills(this, storage, ai)
        createChannel()
        initTts()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            stopAssistant()
            return START_NOT_STICKY
        }
        try {
            ensureForeground()
        } catch (e: Exception) {
            addLog("Не вдалося запустити фонову службу: ${e.message}")
            stopSelf()
            return START_NOT_STICKY
        }
        updateWakeLock()

        when (action) {
            ACTION_LISTEN -> if (!busy) {
                handler.removeCallbacks(restartRunnable)
                startListening(true)
            }
            ACTION_RELOAD -> {
                applyTtsSettings()
                if (!busy) {
                    destroyRecognizer()
                    scheduleNext(100)
                }
            }
            ACTION_TEXT -> {
                val text = intent?.getStringExtra("text")
                if (!text.isNullOrBlank() && !busy) {
                    handler.removeCallbacks(restartRunnable)
                    destroyRecognizer()
                    process(text)
                }
            }
            ACTION_STOP_RECORD -> finishRecording()
            ACTION_UNMUTE -> muteBeep(false)
            ACTION_INCOMING -> if (!busy) {
                busy = true
                setMode("busy")
                handler.removeCallbacks(restartRunnable)
                addLog("Арчік: Вам телефонують. Підняти слухавку?")
                speak("Вам телефонують. Підняти слухавку?") {
                    busy = false
                    startListening(true)
                }
            }
            ACTION_SPEAK -> {
                val text = intent?.getStringExtra("text")
                if (!text.isNullOrBlank() && !busy) {
                    busy = true
                    setMode("busy")
                    handler.removeCallbacks(restartRunnable)
                    addLog("Арчік: $text")
                    speak(text) {
                        busy = false
                        scheduleNext(300)
                    }
                }
            }
            else -> if (!busy) scheduleNext(100)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        muteBeep(false)
        if (Recorder.active) Recorder.stop(this)
        stopped = true
        running = false
        setMode("off")
        handler.removeCallbacksAndMessages(null)
        destroyRecognizer()
        tts?.stop()
        tts?.shutdown()
        tts = null
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        super.onDestroy()
    }

    // ---------- керування ----------

    private fun stopAssistant() {
        muteBeep(false)
        if (Recorder.active) Recorder.stop(this)
        stopped = true
        running = false
        setMode("off")
        handler.removeCallbacksAndMessages(null)
        destroyRecognizer()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private val restartRunnable = Runnable {
        if (stopped || busy) return@Runnable
        if (Recorder.active) return@Runnable
        updateWakeLock()
        if (storage.wakeEnabled) {
            updateNotification("Слухаю: скажіть «${storage.wakeWord}»")
            startListening(false)
        } else {
            destroyRecognizer()
            setMode("idle")
            updateNotification("Очікую. Натисніть «Слухати»")
        }
    }

    private fun scheduleNext(delayMs: Long) {
        handler.removeCallbacks(restartRunnable)
        handler.postDelayed(restartRunnable, delayMs)
    }

    private fun updateWakeLock() {
        val need = storage.wakeEnabled && !stopped
        if (need && wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "assistant:listen")
                .apply { acquire() }
        } else if (!need) {
            wakeLock?.let { if (it.isHeld) it.release() }
            wakeLock = null
        }
    }

    private val mutedStreams = HashSet<Int>()

    /** Глушимо «пік» системного розпізнавача, поки Арчік чекає слово-активацію. */
    private fun muteBeep(on: Boolean) {
        val am = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        if (on) {
            if (!storage.muteBeep || mutedStreams.isNotEmpty()) return
            if (CallState.ringing || CallState.offhook) return
            val musicOn = LocalMusic.isPlaying || am.isMusicActive
            val streams = mutableListOf(
                android.media.AudioManager.STREAM_NOTIFICATION,
                android.media.AudioManager.STREAM_SYSTEM
            )
            if (!musicOn) streams.add(android.media.AudioManager.STREAM_MUSIC)
            for (st in streams) {
                try {
                    am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_MUTE, 0)
                    mutedStreams.add(st)
                } catch (e: Exception) {
                    // цей потік змінити не дозволено
                }
            }
        } else {
            for (st in mutedStreams) {
                try {
                    am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_UNMUTE, 0)
                } catch (e: Exception) {
                }
            }
            mutedStreams.clear()
        }
    }

    // ---------- розпізнавання мовлення ----------

    private fun startListening(command: Boolean) {
        if (stopped) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            addLog("Немає дозволу на мікрофон. Дайте його в налаштуваннях телефону.")
            stopAssistant()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addLog("На телефоні немає служби розпізнавання мовлення. Встановіть або оновіть застосунок Google.")
            stopAssistant()
            return
        }
        listeningForCommand = command
        muteBeep(!command)
        LocalMusic.duck(command)
        setMode(if (command) "command" else "wake")
        if (command) updateNotification("Слухаю команду…")
        destroyRecognizer()
        val id = ++sessionId
        sessionHandled = false
        try {
            val comp = pickRecognizer()
            val r = if (comp != null) SpeechRecognizer.createSpeechRecognizer(this, comp)
            else SpeechRecognizer.createSpeechRecognizer(this)
            r.setRecognitionListener(makeListener(id))
            recognizer = r
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, storage.recogLang)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, storage.recogLang)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 8)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                // довше чекаємо паузу, щоб не обрізати фразу на півслові
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, if (command) 1200L else 1000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, if (command) 1000L else 800L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1500L)
                // Android 13+: один безперервний сеанс замість постійних перезапусків (менше «піків»)
                if (Build.VERSION.SDK_INT >= 33 && !command) {
                    putExtra(RecognizerIntent.EXTRA_SEGMENTED_SESSION, true)
                }
            }
            segmentedActive = Build.VERSION.SDK_INT >= 33 && !command
            r.startListening(intent)
            armWatchdog(id, if (command) 20000L else if (segmentedActive) 60000L else 15000L)
        } catch (e: Exception) {
            scheduleNext(2000)
        }
    }

    /** Якщо розпізнавач «завис» і не дав жодної відповіді, перезапускаємо цикл. */
    private val watchdogRunnable = Runnable {
        if (stopped || busy) return@Runnable
        addLog("Розпізнавач завис, перезапускаю…")
        destroyRecognizer()
        if (listeningForCommand) {
            listeningForCommand = false
        }
        scheduleNext(300)
    }

    private fun armWatchdog(id: Int, ms: Long) {
        if (id != sessionId) return
        handler.removeCallbacks(watchdogRunnable)
        handler.postDelayed(watchdogRunnable, ms)
    }

    private fun clearWatchdog() {
        handler.removeCallbacks(watchdogRunnable)
    }

    /** Завжди беремо розпізнавач Google, а не власну заглушку Арчіка, навіть коли він «помічник за замовчуванням». */
    private fun pickRecognizer(): android.content.ComponentName? {
        return try {
            val list = packageManager.queryIntentServices(
                Intent(android.speech.RecognitionService.SERVICE_INTERFACE), 0
            ).filter { it.serviceInfo.packageName != packageName }
            val g = list.firstOrNull { it.serviceInfo.packageName.contains("google") } ?: list.firstOrNull()
            g?.let { android.content.ComponentName(it.serviceInfo.packageName, it.serviceInfo.name) }
        } catch (e: Exception) {
            null
        }
    }

    private fun destroyRecognizer() {
        clearWatchdog()
        sessionId++
        val r = recognizer ?: return
        recognizer = null
        try {
            r.cancel()
            r.destroy()
        } catch (e: Exception) {
            // ігноруємо
        }
    }

    private fun makeListener(id: Int) = object : RecognitionListener {
        private fun stale() = stopped || id != sessionId

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {
            if (!stale()) armWatchdog(id, 25000L)
        }

        override fun onRmsChanged(rmsdB: Float) {
            if (segmentedActive && !stale()) {
                val now = System.currentTimeMillis()
                if (now - lastRmsArm > 2000) {
                    lastRmsArm = now
                    armWatchdog(id, 60000L)
                }
            }
        }
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {
            if (!stale()) armWatchdog(id, 8000L)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            if (stale()) return
            val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!p.isNullOrBlank()) updateNotification("Чую: ${p.take(60)}")
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (stale()) return
            clearWatchdog()
            if (listeningForCommand) {
                // команду не почули: повертаємось до очікування слова
                listeningForCommand = false
            }
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    addLog("Немає дозволу на мікрофон.")
                    stopAssistant()
                }
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> scheduleNext(120)
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                SpeechRecognizer.ERROR_CLIENT -> scheduleNext(1000)
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER -> scheduleNext(3000)
                else -> scheduleNext(1500)
            }
        }

        override fun onSegmentResults(segmentResults: Bundle) {
            if (stale()) return
            val list = segmentResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
            handleResults(list, true)
        }

        override fun onEndOfSegmentedSession() {
            if (stale()) return
            clearWatchdog()
            scheduleNext(100)
        }

        override fun onResults(results: Bundle?) {
            if (stale() || sessionHandled) return
            sessionHandled = true
            clearWatchdog()
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?: arrayListOf()
            handleResults(list)
        }
    }

    private fun handleResults(list: List<String>, continuing: Boolean = false) {
        if (list.isEmpty()) {
            if (!continuing) scheduleNext(250)
            return
        }
        if (listeningForCommand) {
            listeningForCommand = false
            process(list[0])
            return
        }

        var hit: String? = null
        var range: IntRange? = null
        for (cand in list) {
            val r = findWake(cand.lowercase(uk))
            if (r != null) {
                hit = cand.lowercase(uk)
                range = r
                break
            }
        }
        if (hit == null || range == null) {
            if (list.isNotEmpty()) updateNotification("Почув: ${list[0].take(60)}")
            if (!continuing) scheduleNext(100)
            return
        }
        val after = hit.substring(range.last + 1).trim { !it.isLetterOrDigit() }
        val before = hit.substring(0, range.first).trim { !it.isLetterOrDigit() }
        when {
            after.length >= 3 -> process(after)
            before.length >= 3 -> process(before)
            else -> {
                busy = true
                speak("Слухаю") {
                    busy = false
                    startListening(true)
                }
            }
        }
    }

    private val tokenRegex = Regex("[\\p{L}\\p{N}]+")

    /** Нечітке пошук слова-активації: ловить «Арчі», «Арчик», «Арчіку», «Артік» тощо. */
    private fun findWake(text: String): IntRange? {
        val w = storage.wakeWord.lowercase(uk).trim()
        if (w.isEmpty()) return null
        val aliases = HashSet<String>()
        aliases.add(w)
        if (w == "арчік") aliases.addAll(listOf("арчі", "арчи", "арчик", "арчіку", "артік", "арчіє", "арчіка", "арчика"))
        val stem = w.take(maxOf(3, w.length - 2))
        for (m in tokenRegex.findAll(text)) {
            val t = m.value
            if (t.length < 3) continue
            if (t in aliases) return m.range
            if (t.length >= stem.length && t.startsWith(stem) && t.length <= w.length + 3) return m.range
            if (w.length >= 5 && levenshtein(t, w) <= 1) return m.range
        }
        return null
    }

    private fun levenshtein(a: String, b: String): Int {
        if (kotlin.math.abs(a.length - b.length) > 1) return 2
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length) {
            val c = if (a[i - 1] == b[j - 1]) 0 else 1
            dp[i][j] = minOf(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + c)
        }
        return dp[a.length][b.length]
    }

    // ---------- обробка команд ----------

    private fun process(text: String) {
        busy = true
        setMode("busy")
        addLog("Ви: $text")
        val lower = text.lowercase(uk).trim { !it.isLetterOrDigit() }
        val stopWords = listOf("вимкнись", "вимкнися", "вимкни себе", "вимкни помічника", "вимкни арчіка",
            "вимкни арчі", "вимкнути себе", "вимкнути помічника", "зупинись", "зупинися", "відбій", "годі",
            "вимкни додаток", "вимкни програму", "досить слухати", "припини роботу", "закрийся")
        if (lower == "стоп" || lower == "вимкни" || stopWords.any { lower.contains(it) }) {
            reply("Вимикаюся.") { stopAssistant() }
            return
        }
        if (handleRecorder(lower)) return
        val handledBySkill = try {
            skills.tryHandle(text) { answer, follow -> reply(answer, follow || storage.driveMode) }
        } catch (e: Exception) {
            false
        }
        if (handledBySkill) {
            updateNotification("Думаю…")
            return
        }
        val local = try {
            processor.handle(text)
        } catch (e: Exception) {
            null
        }
        if (local != null) {
            reply(local, processor.expectAnswer)
            return
        }
        if (storage.apiKey.isBlank()) {
            reply("Щоб я відповідав на запитання, додайте ключ для штучного інтелекту в налаштуваннях застосунку.")
            return
        }
        updateNotification("Думаю…")
        streamAnswer(text)
    }

    /** Озвучуємо відповідь ШІ по реченнях, не чекаючи кінця тексту: перше речення звучить за кілька секунд. */
    private fun streamAnswer(question: String) {
        var pending = 0
        var finished = false
        var first = true
        var chars = 0
        val full = StringBuilder()
        fun finish() {
            if (stopped) return
            addLog("Арчік: ${full.toString().trim()}")
            busy = false
            startListening(true)
        }
        ai.askStream(
            question,
            onSentence = { sentence ->
                if (!stopped) {
                    full.append(sentence).append(' ')
                    pending++
                    val flush = first
                    first = false
                    val ahead = chars
                    chars += sentence.length
                    speak(sentence, 0, flush, ahead) {
                        pending--
                        if (finished && pending == 0) finish()
                    }
                }
            },
            onDone = {
                finished = true
                if (pending == 0) finish()
            }
        )
    }

    /**
     * followUp = true: після відповіді одразу слухаємо далі без слова-активації (режим розмови).
     * Якщо людина мовчить, Арчік повертається до очікування слова «Арчік».
     */
    private fun reply(text: String, followUp: Boolean = false, after: (() -> Unit)? = null) {
        if (stopped) return
        addLog("Арчік: $text")
        speak(text) {
            busy = false
            when {
                after != null -> after()
                followUp && !stopped -> startListening(true)
                else -> scheduleNext(300)
            }
        }
    }

    // ---------- диктофон ----------

    private fun handleRecorder(t: String): Boolean {
        val openApp = t.contains("програм") || t.contains("додаток") || t.contains("застосунок")
        val start = (t.contains("диктофон") && !openApp &&
            listOf("увімкни", "включи", "запусти", "відкрий", "почни", "розпочни", "запиши").any { t.contains(it) }) ||
            listOf("почни запис", "розпочни запис", "почати запис", "запиши розмову", "запиши звук", "запиши мене",
                "увімкни запис", "включи запис").any { t.contains(it) }
        val stop = listOf("зупини запис", "заверши запис", "закінчи запис", "стоп запис", "вимкни диктофон",
            "зупини диктофон", "зупинити запис").any { t.contains(it) }
        val play = listOf("відтвори останній запис", "відтвори запис", "послухати запис", "прослухати запис",
            "увімкни останній запис").any { t.contains(it) }
        when {
            stop -> {
                if (Recorder.active) {
                    finishRecording()
                } else {
                    reply("Запис зараз не йде.")
                }
                return true
            }
            play -> {
                val id = storage.lastRecording
                if (id < 0) {
                    reply("Збережених записів ще немає.")
                } else {
                    LocalMusic.play(this, listOf(LocalMusic.Track(id, "Запис", "Диктофон", "")))
                    reply("Відтворюю останній запис.")
                }
                return true
            }
            start -> {
                val m = Regex("(\\d+) ?(хвилин|хв|годин|год)").find(t)
                val maxMs = if (m != null) {
                    m.groupValues[1].toLong() * (if (m.groupValues[2].startsWith("год")) 3_600_000L else 60_000L)
                } else {
                    2 * 3_600_000L
                }
                val stopHow = if (m != null) "Запис зупиниться сам." else
                    "Щоб зупинити, торкніться мікрофона або кнопки в сповіщенні."
                reply("Починаю запис. $stopHow Під час запису я вас не чую.", false) {
                    val err = Recorder.start(this, maxMs)
                    if (err != null) {
                        reply(err)
                    } else {
                        Recorder.onAutoStop = { finishRecording() }
                        destroyRecognizer()
                        setMode("record")
                        updateNotification("Йде запис…")
                    }
                }
                return true
            }
        }
        return false
    }

    private fun finishRecording() {
        val name = Recorder.stop(this)
        Recorder.onAutoStop = null
        if (name == null) return
        busy = true
        setMode("busy")
        reply("Запис збережено: $name. Шукайте його в папці Арчік у музиці чи записах.")
    }

    // ---------- озвучення ----------

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val engine = tts
                if (engine != null) {
                    engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) {
                            finishUtterance(utteranceId)
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            finishUtterance(utteranceId)
                        }

                        override fun onError(utteranceId: String?, errorCode: Int) {
                            finishUtterance(utteranceId)
                        }
                    })
                    ttsReady = true
                    applyTtsSettings()
                }
            }
        }
    }

    private fun applyTtsSettings() {
        val engine = tts ?: return
        if (!ttsReady) return
        val res = engine.setLanguage(Locale.forLanguageTag(storage.ttsLang))
        ttsUkOk = res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED
        val voiceName = storage.ttsVoice
        if (voiceName.isNotEmpty()) {
            try {
                engine.voices?.firstOrNull { it.name == voiceName }?.let { engine.setVoice(it) }
            } catch (e: Exception) {
                // залишаємо стандартний голос
            }
        }
        engine.setSpeechRate(storage.speechRate)
        warnedTts = false
    }

    private fun finishUtterance(id: String?) {
        handler.post { speakCallbacks.remove(id)?.invoke() }
    }

    private fun speak(text: String, attempt: Int = 0, flush: Boolean = true, charsAhead: Int = 0, done: () -> Unit) {
        destroyRecognizer()
        muteBeep(false)
        LocalMusic.duck(true)
        val engine = tts
        if (engine == null || !ttsReady) {
            if (attempt < 10) {
                handler.postDelayed({ speak(text, attempt + 1, flush, charsAhead, done) }, 400)
            } else {
                done()
            }
            return
        }
        if (!ttsUkOk) {
            if (!warnedTts) {
                warnedTts = true
                addLog("Немає голосу для вибраної мови озвучення. Встановіть його: Налаштування → Мова → Синтез мовлення.")
            }
            done()
            return
        }
        val id = "u${++utteranceCounter}"
        speakCallbacks[id] = done
        val r = engine.speak(text, if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, id)
        if (r != TextToSpeech.SUCCESS) {
            speakCallbacks.remove(id)
            done()
            return
        }
        // страховка: якщо синтезатор не повідомив про завершення, не залишаємось у стані «зайнято»
        val limit = 8000L + (text.length + charsAhead) * 130L
        handler.postDelayed({
            speakCallbacks.remove(id)?.let {
                try {
                    engine.stop()
                } catch (e: Exception) {
                }
                it()
            }
        }, limit)
    }

    // ---------- сповіщення ----------

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Арчік",NotificationManager.IMPORTANCE_LOW)
        )
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val listen = PendingIntent.getService(
            this, 1,
            Intent(this, AssistantService::class.java).setAction(ACTION_LISTEN),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 2,
            Intent(this, AssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Арчік")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                if (Recorder.active) {
                    Notification.Action.Builder(
                        0, "Зупинити запис",
                        PendingIntent.getService(
                            this, 3,
                            Intent(this, AssistantService::class.java).setAction(ACTION_STOP_RECORD),
                            PendingIntent.FLAG_IMMUTABLE
                        )
                    ).build()
                } else {
                    Notification.Action.Builder(0, "Слухати", listen).build()
                }
            )
            .addAction(Notification.Action.Builder(0, "Зупинити", stop).build())
            .build()
    }

    private fun ensureForeground() {
        if (foregroundStarted) return
        val text = "Запускаюсь…"
        val n = buildNotification(text)
        if (Build.VERSION.SDK_INT >= 30) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            if (Build.VERSION.SDK_INT >= 29 && Geo.hasPermission(this)) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            }
            startForeground(NOTIF_ID, n, type)
        } else {
            startForeground(NOTIF_ID, n)
        }
        lastNotifText = text
        foregroundStarted = true
        running = true
    }

    private fun updateNotification(text: String) {
        if (!foregroundStarted || text == lastNotifText) return
        lastNotifText = text
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }
}
