package ua.helper.assistant

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Відповіді ШІ. Провайдер визначається за ключем:
 *  - ключ, що починається з "sk-ant-", це Claude (платний);
 *  - будь-який інший (зазвичай "AIza..."), це Google Gemini (є безкоштовний рівень).
 */
class AiClient(private val storage: Storage) {

    companion object {
        private const val CLAUDE_MODEL = "claude-haiku-5-5"
        private const val CLAUDE_URL = "https://api.anthropic.com/v1/messages"
        private const val GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models/"

        // Якщо одна модель перевантажена (503) або вичерпала ліміт (429), пробуємо наступну.
        private val GEMINI_MODELS =
            listOf("gemini-2.5-flash", "gemini-flash-lite-latest", "gemini-flash-latest")

        // Пошук в інтернеті сильно сповільнює відповідь, тому вмикаємо його лише коли потрібні свіжі дані.
        private val SEARCH_HINTS = listOf(
            "новин", "курс", "ціна", "ціни", "скільки коштує", "вартість", "погод", "сьогодні", "зараз",
            "вчора", "завтра", "останн", "свіж", "актуальн", "хто виграв", "рахунок", "матч", "результат",
            "коли вийде", "вийшов", "2025", "2026", "президент", "прем'єр", "що сталося", "що нового",
            "розклад", "біткоїн", "долар", "євро", "гривн", "нафт", "новини", "news", "price", "latest"
        )

        private fun needsSearch(q: String): Boolean {
            val l = q.lowercase(Locale("uk", "UA"))
            return SEARCH_HINTS.any { l.contains(it) }
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val history = mutableListOf<Pair<String, String>>() // ("user"|"assistant", текст)

    fun ask(question: String, callback: (String) -> Unit) {
        Thread {
            val answer = try {
                if (storage.apiKey.startsWith("sk-ant-")) requestClaude(question) else requestGemini(question)
            } catch (e: Exception) {
                "Не вдалося отримати відповідь. Перевірте інтернет і ключ."
            }
            mainHandler.post { callback(answer) }
        }.start()
    }

    private fun system(): String {
        val now = SimpleDateFormat("d MMMM yyyy, EEEE, HH:mm", Locale("uk", "UA")).format(Date())
        return "Ти Арчік: голосовий помічник у смартфоні і добрий співрозмовник. " +
            "Відповідай виключно ${Languages.find(storage.ttsLang).adjective} мовою. Говори тепло й невимушено, як друг. " +
            "Відповідай живою мовою, зазвичай двома-чотирма реченнями, без списків, markdown, емодзі й спецсимволів, " +
            "бо твою відповідь озвучують голосом. Можеш поставити одне коротке запитання у відповідь, щоб підтримати розмову, " +
            "і давати поради. У питаннях здоров'я, грошей чи права давай обережні загальні поради " +
            "й раджай звернутися до фахівця, коли це справді важливо. " +
            "Для актуальних даних (новини, курси валют, ціни, спорт, події, факти після 2024 року) користуйся пошуком в інтернеті " +
            "й коротко називай джерело; якщо пошук не дав відповіді, чесно скажи про це. " +
            "Поточна дата й час користувача: $now."
    }

    private fun remember(question: String, answer: String) {
        synchronized(history) {
            history.add("user" to question)
            history.add("assistant" to answer)
            while (history.size > 16) {
                history.removeAt(0)
                history.removeAt(0)
            }
        }
    }

    private fun post(
        url: String, headers: Map<String, String>, body: JSONObject, readTimeoutMs: Int = 40000
    ): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = readTimeoutMs
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return code to text
        } finally {
            conn.disconnect()
        }
    }

    /** Як post, але таймаут чи збій мережі не обриває все: повертає код 0, і ми пробуємо наступну модель. */
    private fun postSafe(
        url: String, headers: Map<String, String>, body: JSONObject, readTimeoutMs: Int
    ): Pair<Int, String> = try {
        post(url, headers, body, readTimeoutMs)
    } catch (e: java.net.SocketTimeoutException) {
        0 to ""
    }

    private fun logDetails(provider: String, code: Int, body: String) {
        val msg = try {
            JSONObject(body).getJSONObject("error").optString("message")
        } catch (e: Exception) {
            body
        }
        mainHandler.post { AssistantService.addLog("$provider, код $code: ${msg.take(300)}") }
    }

    private fun errorMessage(code: Int): String? = when (code) {
        400, 401, 403 -> "Ключ не підійшов або немає доступу. Перевірте ключ у налаштуваннях."
        0 -> "Сервіс ШІ не відповів вчасно. Спробуйте ще раз."
        404 -> "Модель ШІ недоступна. Напишіть розробнику."
        429 -> "Ліміт запитів вичерпано. Спробуйте за хвилину або пізніше."
        in 500..599 -> "Сервіс ШІ тимчасово недоступний. Спробуйте пізніше."
        else -> if (code in 200..299) null else "Сервіс ШІ повернув помилку $code."
    }

    // ---------- Claude ----------

    private fun requestClaude(question: String): String {
        val messages = JSONArray()
        val snapshot = synchronized(history) { history.toList() }
        for ((role, text) in snapshot) {
            messages.put(JSONObject().put("role", role).put("content", text))
        }
        messages.put(JSONObject().put("role", "user").put("content", question))

        val body = JSONObject()
            .put("model", CLAUDE_MODEL)
            .put("max_tokens", 400)
            .put("system", system())
            .put("messages", messages)
        val useSearch = needsSearch(question)
        if (useSearch) {
            body.put(
                "tools",
                JSONArray().put(
                    JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 2)
                )
            )
        }

        val headers = mapOf("x-api-key" to storage.apiKey, "anthropic-version" to "2023-06-01")
        var (code, text) = post(CLAUDE_URL, headers, body, if (useSearch) 45000 else 25000)
        if (useSearch && code !in 200..299 && code != 401 && code != 403 && code != 429) {
            // пошук недоступний для цього ключа: відповідаємо без нього
            body.remove("tools")
            val r = post(CLAUDE_URL, headers, body, 25000)
            code = r.first
            text = r.second
        }
        errorMessage(code)?.let { return it }

        val content = JSONObject(text).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val block = content.getJSONObject(i)
            if (block.optString("type") == "text") sb.append(block.optString("text"))
        }
        val answer = sb.toString().trim()
        if (answer.isEmpty()) return "Відповідь порожня. Спробуйте ще раз."
        remember(question, answer)
        return answer
    }

    // ---------- Gemini (безкоштовний рівень) ----------

    /** thinkingBudget = 0 вимикає довгі «роздуми» моделі: відповідь приходить у кілька разів швидше. */
    private fun gemConfig(maxTokens: Int, thinkingOff: Boolean): JSONObject {
        val c = JSONObject().put("maxOutputTokens", maxTokens)
        if (thinkingOff) c.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        return c
    }

    private fun requestGemini(question: String): String {
        val contents = JSONArray()
        val snapshot = synchronized(history) { history.toList() }
        for ((role, text) in snapshot) {
            contents.put(
                JSONObject()
                    .put("role", if (role == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        contents.put(
            JSONObject()
                .put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", question)))
        )

        val body = JSONObject()
            .put(
                "system_instruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system())))
            )
            .put("contents", contents)
            .put("generationConfig", gemConfig(400, thinkingOff = true))

        val key = storage.apiKey
        var code = 0
        var text = ""
        // пошук Google лише для питань про свіжі дані; решта відповідається миттєво
        val modes = if (needsSearch(question)) listOf(true, false) else listOf(false)
        for (withSearch in modes) {
            if (withSearch) {
                body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            } else {
                body.remove("tools")
            }
            val timeout = if (withSearch) 30000 else 20000
            for (model in GEMINI_MODELS) {
                var r = postSafe("$GEMINI_BASE$model:generateContent", mapOf("x-goog-api-key" to key), body, timeout)
                if (r.first == 400) {
                    // модель не вміє вимикати «роздуми»: пробуємо без цього параметра
                    body.put("generationConfig", gemConfig(400, thinkingOff = false))
                    r = postSafe("$GEMINI_BASE$model:generateContent", mapOf("x-goog-api-key" to key), body, timeout)
                    body.put("generationConfig", gemConfig(400, thinkingOff = true))
                }
                code = r.first
                text = r.second
                if (code in 200..299) break
                if (code == 401 || code == 403) break
                if (code == 400) break
            }
            if (code in 200..299 || code == 401 || code == 403) break
        }
        if (code !in 200..299) logDetails("Gemini", code, text)
        errorMessage(code)?.let { return it }

        val parts = JSONObject(text)
            .optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        }
        val answer = sb.toString().trim()
        if (answer.isEmpty()) return "Відповідь порожня. Спробуйте переформулювати запитання."
        remember(question, answer)
        return answer
    }

    // ---------- потокова відповідь: Арчік починає говорити з першого речення ----------

    /** Ріже текст, що надходить шматками, на речення і віддає кожне, щойно воно готове. */
    private class SentenceSplitter(private val emit: (String) -> Unit) {
        private val buf = StringBuilder()
        private val end = Regex("[.!?…]+[\"»”')]*\\s")

        fun add(t: String) {
            buf.append(t)
            drain(false)
        }

        fun flush() = drain(true)

        private fun clean(s: String) = s.replace("*", "").replace("#", "").replace("_", " ").trim()

        private fun drain(final: Boolean) {
            while (true) {
                val s = buf.toString()
                var cut = end.findAll(s).firstOrNull { it.range.last + 1 >= 8 }?.let { it.range.last + 1 } ?: -1
                if (cut < 0 && s.length > 160) {
                    val c = s.lastIndexOf(", ", 160)
                    cut = if (c > 40) c + 1 else s.lastIndexOf(' ', 160).let { if (it > 40) it else -1 }
                }
                if (cut < 0) break
                val sentence = clean(s.substring(0, cut))
                buf.delete(0, cut)
                if (sentence.isNotEmpty()) emit(sentence)
            }
            if (final) {
                val rest = clean(buf.toString())
                buf.setLength(0)
                if (rest.isNotEmpty()) emit(rest)
            }
        }
    }

    /**
     * Відповідь ШІ потоком. onSentence викликається в головному потоці для кожного готового речення,
     * onDone після завершення (також при помилці: тоді помилка приходить як одне речення).
     */
    fun askStream(question: String, onSentence: (String) -> Unit, onDone: () -> Unit) {
        Thread {
            val full = StringBuilder()
            val splitter = SentenceSplitter { sentence -> mainHandler.post { onSentence(sentence) } }
            var error: String? = null
            try {
                error = if (storage.apiKey.startsWith("sk-ant-")) {
                    streamClaude(question, splitter, full)
                } else {
                    streamGemini(question, splitter, full)
                }
            } catch (e: Exception) {
                error = "Не вдалося отримати відповідь. Перевірте інтернет і ключ."
            }
            if (full.isEmpty()) {
                mainHandler.post { onSentence(error ?: "Відповідь порожня. Спробуйте ще раз.") }
            } else {
                splitter.flush()
                remember(question, full.toString().trim())
            }
            mainHandler.post { onDone() }
        }.start()
    }

    private fun postStream(
        url: String, headers: Map<String, String>, body: JSONObject, readTimeoutMs: Int,
        onLine: (String) -> Unit
    ): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10000
            conn.readTimeout = readTimeoutMs
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code !in 200..299) {
                val text = conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                return code to text
            }
            conn.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    onLine(line)
                }
            }
            return code to ""
        } catch (e: java.net.SocketTimeoutException) {
            return 0 to ""
        } finally {
            conn.disconnect()
        }
    }

    private fun streamClaude(question: String, sp: SentenceSplitter, full: StringBuilder): String? {
        val messages = JSONArray()
        val snapshot = synchronized(history) { history.toList() }
        for ((role, text) in snapshot) {
            messages.put(JSONObject().put("role", role).put("content", text))
        }
        messages.put(JSONObject().put("role", "user").put("content", question))
        val body = JSONObject()
            .put("model", CLAUDE_MODEL)
            .put("max_tokens", 400)
            .put("stream", true)
            .put("system", system())
            .put("messages", messages)
        val useSearch = needsSearch(question)
        if (useSearch) {
            body.put(
                "tools",
                JSONArray().put(
                    JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 2)
                )
            )
        }
        val headers = mapOf("x-api-key" to storage.apiKey, "anthropic-version" to "2023-06-01")
        val onLine: (String) -> Unit = { line ->
            if (line.startsWith("data:")) {
                try {
                    val j = JSONObject(line.substring(5).trim())
                    if (j.optString("type") == "content_block_delta") {
                        val d = j.optJSONObject("delta")
                        if (d != null && d.optString("type") == "text_delta") {
                            val t = d.optString("text")
                            full.append(t)
                            sp.add(t)
                        }
                    }
                } catch (e: Exception) {
                    // пропускаємо службовий рядок
                }
            }
        }
        var (code, text) = postStream(CLAUDE_URL, headers, body, if (useSearch) 45000 else 25000, onLine)
        if (useSearch && full.isEmpty() && code !in 200..299 && code != 0 &&
            code != 401 && code != 403 && code != 429
        ) {
            body.remove("tools")
            val r = postStream(CLAUDE_URL, headers, body, 25000, onLine)
            code = r.first
            text = r.second
        }
        if (code !in 200..299 && text.isNotEmpty()) logDetails("Claude", code, text)
        return errorMessage(code)
    }

    private fun streamGemini(question: String, sp: SentenceSplitter, full: StringBuilder): String? {
        val contents = JSONArray()
        val snapshot = synchronized(history) { history.toList() }
        for ((role, text) in snapshot) {
            contents.put(
                JSONObject()
                    .put("role", if (role == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        contents.put(
            JSONObject()
                .put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", question)))
        )
        val body = JSONObject()
            .put(
                "system_instruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system())))
            )
            .put("contents", contents)
            .put("generationConfig", gemConfig(400, thinkingOff = true))

        val onLine: (String) -> Unit = { line ->
            if (line.startsWith("data:")) {
                try {
                    val parts = JSONObject(line.substring(5).trim())
                        .optJSONArray("candidates")?.optJSONObject(0)
                        ?.optJSONObject("content")?.optJSONArray("parts")
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            val t = parts.getJSONObject(i).optString("text")
                            if (t.isNotEmpty()) {
                                full.append(t)
                                sp.add(t)
                            }
                        }
                    }
                } catch (e: Exception) {
                    // пропускаємо службовий рядок
                }
            }
        }
        val key = storage.apiKey
        var code = 0
        var text = ""
        val modes = if (needsSearch(question)) listOf(true, false) else listOf(false)
        for (withSearch in modes) {
            if (withSearch) {
                body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            } else {
                body.remove("tools")
            }
            val timeout = if (withSearch) 30000 else 20000
            for (model in GEMINI_MODELS) {
                val url = "$GEMINI_BASE$model:streamGenerateContent?alt=sse"
                var r = postStream(url, mapOf("x-goog-api-key" to key), body, timeout, onLine)
                if (r.first == 400) {
                    body.put("generationConfig", gemConfig(400, thinkingOff = false))
                    r = postStream(url, mapOf("x-goog-api-key" to key), body, timeout, onLine)
                    body.put("generationConfig", gemConfig(400, thinkingOff = true))
                }
                code = r.first
                text = r.second
                if (code in 200..299 || full.isNotEmpty()) break
                if (code == 401 || code == 403 || code == 400) break
            }
            if (code in 200..299 || full.isNotEmpty() || code == 401 || code == 403) break
        }
        if (code !in 200..299 && text.isNotEmpty()) logDetails("Gemini", code, text)
        return errorMessage(code)
    }

    // ---------- окремі завдання: малюнки, документи, математика ----------

    /**
     * Одноразовий запит без історії розмови. file = (mime, байти) для PDF і зображень.
     * callback(текст, помилка) викликається в головному потоці.
     */
    fun generate(
        system: String,
        user: String,
        maxTokens: Int,
        file: Pair<String, ByteArray>? = null,
        callback: (String?, String?) -> Unit
    ) {
        Thread {
            var text: String? = null
            var err: String? = null
            try {
                val r = if (storage.apiKey.startsWith("sk-ant-")) {
                    generateClaude(system, user, maxTokens, file)
                } else {
                    generateGemini(system, user, maxTokens, file)
                }
                text = r.first
                err = r.second
            } catch (e: Exception) {
                err = "Не вдалося отримати відповідь. Перевірте інтернет і ключ."
            }
            mainHandler.post { callback(text, err) }
        }.start()
    }

    private fun generateClaude(
        system: String, user: String, maxTokens: Int, file: Pair<String, ByteArray>?
    ): Pair<String?, String?> {
        val content = JSONArray()
        if (file != null) {
            val b64 = android.util.Base64.encodeToString(file.second, android.util.Base64.NO_WRAP)
            val type = if (file.first == "application/pdf") "document" else "image"
            content.put(
                JSONObject().put("type", type).put(
                    "source",
                    JSONObject().put("type", "base64").put("media_type", file.first).put("data", b64)
                )
            )
        }
        content.put(JSONObject().put("type", "text").put("text", user))
        val body = JSONObject()
            .put("model", CLAUDE_MODEL)
            .put("max_tokens", maxTokens)
            .put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val (code, text) = post(
            CLAUDE_URL,
            mapOf("x-api-key" to storage.apiKey, "anthropic-version" to "2023-06-01"),
            body, 120000
        )
        errorMessage(code)?.let { return null to it }
        val arr = JSONObject(text).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val b = arr.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.optString("text"))
        }
        val out = sb.toString().trim()
        return if (out.isEmpty()) null to "Відповідь порожня. Спробуйте ще раз." else out to null
    }

    private fun generateGemini(
        system: String, user: String, maxTokens: Int, file: Pair<String, ByteArray>?
    ): Pair<String?, String?> {
        val parts = JSONArray()
        if (file != null) {
            val b64 = android.util.Base64.encodeToString(file.second, android.util.Base64.NO_WRAP)
            parts.put(
                JSONObject().put(
                    "inline_data", JSONObject().put("mime_type", file.first).put("data", b64)
                )
            )
        }
        parts.put(JSONObject().put("text", user))
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("maxOutputTokens", maxTokens))
        var code = 0
        var text = ""
        for (model in GEMINI_MODELS) {
            val r = post("$GEMINI_BASE$model:generateContent", mapOf("x-goog-api-key" to storage.apiKey), body, 120000)
            code = r.first
            text = r.second
            if (code in 200..299) break
            if (code == 400 || code == 401 || code == 403) break
        }
        if (code !in 200..299) logDetails("Gemini", code, text)
        errorMessage(code)?.let { return null to it }
        val ps = JSONObject(text).optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (ps != null) for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text"))
        val out = sb.toString().trim()
        return if (out.isEmpty()) null to "Відповідь порожня. Спробуйте переформулювати." else out to null
    }

    fun languageName(): String = Languages.find(storage.ttsLang).adjective
}
