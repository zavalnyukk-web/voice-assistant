package ua.helper.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_DISMISS = "ua.helper.assistant.DISMISS_ALARM"
        private var ringtone: android.media.Ringtone? = null
        private val h = android.os.Handler(android.os.Looper.getMainLooper())
        private val stopRing = Runnable { stopRingtone() }

        fun stopRingtone() {
            h.removeCallbacks(stopRing)
            try {
                ringtone?.stop()
            } catch (e: Exception) {
            }
            ringtone = null
        }

        fun startRingtone(context: Context) {
            stopRingtone()
            try {
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                val rt = RingtoneManager.getRingtone(context.applicationContext, uri)
                rt.audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                if (Build.VERSION.SDK_INT >= 28) rt.isLooping = true
                rt.play()
                ringtone = rt
                h.postDelayed(stopRing, 60_000)
            } catch (e: Exception) {
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_DISMISS) {
            stopRingtone()
            (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .cancel(1000 + intent.getIntExtra("id", 0))
            return
        }
        val id = intent.getIntExtra("id", 0)
        val text = intent.getStringExtra("text") ?: return
        val alarm = intent.getBooleanExtra("alarm", false)
        Storage(context).removeReminder(id)

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val open = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE
        )

        val builder: Notification.Builder
        if (alarm) {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val channel = NotificationChannel("alarms", "Будильники й таймери", NotificationManager.IMPORTANCE_HIGH)
            channel.setSound(
                uri,
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            channel.enableVibration(true)
            channel.vibrationPattern = longArrayOf(0, 800, 400, 800, 400, 800)
            nm.createNotificationChannel(channel)
            builder = Notification.Builder(context, "alarms")
                .setCategory(Notification.CATEGORY_ALARM)
                .setFullScreenIntent(open, true)
                .setTimeoutAfter(120_000)
                .setContentTitle(text)
                .setContentText("Натисніть, щоб відкрити Арчіка")
                .addAction(
                    Notification.Action.Builder(
                        0, "Вимкнути",
                        PendingIntent.getBroadcast(
                            context, 5000 + id,
                            Intent(context, ReminderReceiver::class.java).setAction(ACTION_DISMISS).putExtra("id", id),
                            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                        )
                    ).build()
                )
        } else {
            nm.createNotificationChannel(
                NotificationChannel("reminders", "Нагадування", NotificationManager.IMPORTANCE_HIGH)
            )
            builder = Notification.Builder(context, "reminders")
                .setContentTitle("Нагадування")
                .setContentText(text)
        }

        val n = builder
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        if (alarm) n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(1000 + id, n)
        if (alarm) startRingtone(context)

        if (!alarm && AssistantService.running) {
            try {
                context.startService(
                    Intent(context, AssistantService::class.java)
                        .setAction(AssistantService.ACTION_SPEAK)
                        .putExtra("text", "Нагадування: $text")
                )
            } catch (e: Exception) {
                // сповіщення вже показано
            }
        }
    }
}
