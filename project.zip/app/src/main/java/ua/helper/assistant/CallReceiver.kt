package ua.helper.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

/** Стан вхідного дзвінка, щоб Арчік міг запитати «підняти слухавку?». */
object CallState {
    @Volatile
    var ringing = false

    @Volatile
    var offhook = false
}

class CallReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        when (intent.getStringExtra(TelephonyManager.EXTRA_STATE)) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                if (CallState.ringing) return
                CallState.ringing = true
                try {
                    context.startService(
                        Intent(context, AssistantService::class.java).setAction(AssistantService.ACTION_UNMUTE)
                    )
                } catch (e: Exception) {
                }
                if (AssistantService.running && Storage(context).announceCalls) {
                    try {
                        context.startService(
                            Intent(context, AssistantService::class.java).setAction(AssistantService.ACTION_INCOMING)
                        )
                    } catch (e: Exception) {
                        // ігноруємо
                    }
                }
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                CallState.ringing = false
                CallState.offhook = true
            }
            else -> {
                CallState.ringing = false
                CallState.offhook = false
            }
        }
    }
}
