package ua.helper.assistant

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.MediaStore
import java.util.Locale

/** Музика з файлів у телефоні: пошук у бібліотеці й власний програвач, яким керує Арчік. */
object LocalMusic {
    class Track(val id: Long, val title: String, val artist: String, val album: String) {
        val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
        val hay: String = norm("$artist $title $album")
        val hayLat: String = translit(hay)
    }

    private var library: List<Track>? = null
    private var queue: List<Track> = emptyList()
    private var index = 0
    private var player: MediaPlayer? = null
    private var paused = false
    private var ducked = false
    private var focusRequest: AudioFocusRequest? = null

    fun permissionName(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasPermission(c: Context) =
        c.checkSelfPermission(permissionName()) == PackageManager.PERMISSION_GRANTED

    /** true, якщо власний програвач щось грає або стоїть на паузі. */
    val active: Boolean get() = player != null
    val isPlaying: Boolean get() = try { player?.isPlaying == true } catch (e: Exception) { false }
    fun current(): Track? = queue.getOrNull(index)

    private fun norm(s: String) = s.lowercase(Locale("uk", "UA"))
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()

    private val map = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "h", 'ґ' to "g", 'д' to "d", 'е' to "e", 'є' to "ye",
        'ж' to "zh", 'з' to "z", 'и' to "y", 'і' to "i", 'ї' to "yi", 'й' to "y", 'к' to "k", 'л' to "l",
        'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t", 'у' to "u",
        'ф' to "f", 'х' to "kh", 'ц' to "ts", 'ч' to "ch", 'ш' to "sh", 'щ' to "shch", 'ь' to "", 'ю' to "yu",
        'я' to "ya", 'ы' to "y", 'э' to "e", 'ъ' to "", 'ё' to "yo"
    )

    private fun translit(s: String): String {
        val sb = StringBuilder()
        for (ch in s) sb.append(map[ch] ?: ch.toString())
        return sb.toString()
    }

    fun load(c: Context, force: Boolean = false): List<Track> {
        library?.let { if (!force) return it }
        val out = ArrayList<Track>()
        val cur = c.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            arrayOf(
                MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM
            ),
            MediaStore.Audio.Media.IS_MUSIC + "!=0", null, null
        )
        cur?.use {
            while (it.moveToNext()) {
                out.add(Track(it.getLong(0), it.getString(1) ?: "", it.getString(2) ?: "", it.getString(3) ?: ""))
            }
        }
        library = out
        return out
    }

    fun search(c: Context, query: String): List<Track> {
        val words = norm(query).split(" ").filter { it.length >= 2 }
        if (words.isEmpty()) return emptyList()
        val lib = load(c, true)
        data class Hit(val t: Track, val score: Int)
        val hits = ArrayList<Hit>()
        for (t in lib) {
            var score = 0
            for (w in words) {
                val stem = if (w.length >= 5) w.dropLast(1) else w
                val stemLat = translit(stem)
                if (t.hay.contains(stem) || t.hayLat.contains(stemLat)) score++
            }
            if (score > 0) hits.add(Hit(t, score))
        }
        if (hits.isEmpty()) return emptyList()
        val best = hits.maxOf { it.score }
        return hits.filter { it.score == best }.map { it.t }.sortedBy { it.artist + it.title }.take(200)
    }

    fun all(c: Context): List<Track> = load(c, true).shuffled()

    // ---------- програвач ----------

    fun play(c: Context, tracks: List<Track>, shuffle: Boolean = false) {
        if (tracks.isEmpty()) return
        queue = if (shuffle) tracks.shuffled() else tracks
        index = 0
        startCurrent(c.applicationContext)
    }

    private fun startCurrent(c: Context) {
        stopPlayer()
        val t = queue.getOrNull(index) ?: return
        requestFocus(c)
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setWakeMode(c, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setDataSource(c, t.uri)
            mp.setOnCompletionListener {
                if (index + 1 < queue.size) {
                    index++
                    startCurrent(c)
                } else {
                    stop()
                }
            }
            mp.setOnErrorListener { _, _, _ ->
                if (index + 1 < queue.size) {
                    index++
                    startCurrent(c)
                } else {
                    stop()
                }
                true
            }
            mp.prepare()
            mp.setVolume(if (ducked) 0.15f else 1f, if (ducked) 0.15f else 1f)
            mp.start()
            player = mp
            paused = false
        } catch (e: Exception) {
            player = null
            if (index + 1 < queue.size) {
                index++
                startCurrent(c)
            }
        }
    }

    private fun requestFocus(c: Context) {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val listener = AudioManager.OnAudioFocusChangeListener { change ->
            if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                pause()
            }
        }
        if (Build.VERSION.SDK_INT >= 26) {
            val r = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                .setOnAudioFocusChangeListener(listener)
                .build()
            focusRequest = r
            am.requestAudioFocus(r)
        }
    }

    private fun stopPlayer() {
        try {
            player?.stop()
        } catch (e: Exception) {
        }
        try {
            player?.release()
        } catch (e: Exception) {
        }
        player = null
    }

    fun pause(): Boolean {
        val p = player ?: return false
        try {
            if (p.isPlaying) p.pause()
            paused = true
        } catch (e: Exception) {
        }
        return true
    }

    fun resume(): Boolean {
        val p = player ?: return false
        try {
            p.start()
            paused = false
        } catch (e: Exception) {
        }
        return true
    }

    fun next(c: Context): Boolean {
        if (player == null && queue.isEmpty()) return false
        index = if (index + 1 < queue.size) index + 1 else 0
        startCurrent(c.applicationContext)
        return true
    }

    fun previous(c: Context): Boolean {
        if (player == null && queue.isEmpty()) return false
        index = if (index - 1 >= 0) index - 1 else queue.size - 1
        startCurrent(c.applicationContext)
        return true
    }

    fun stop() {
        stopPlayer()
        queue = emptyList()
        index = 0
        paused = false
    }

    /** Тихіше, поки Арчік слухає чи говорить. */
    fun duck(on: Boolean) {
        ducked = on
        try {
            val v = if (on) 0.15f else 1f
            player?.setVolume(v, v)
        } catch (e: Exception) {
        }
    }
}
