package ua.helper.assistant

import android.app.Notification
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Останні повідомлення з месенджерів, щоб Арчік міг їх прочитати вголос. */
object Inbox {
    class Item(val pkg: String, val app: String, val title: String, val text: String)

    val items = ArrayList<Item>()

    fun isEnabled(c: Context): Boolean {
        val s = Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners") ?: return false
        return s.contains(c.packageName)
    }

    fun add(i: Item) {
        synchronized(items) {
            items.removeAll { it.pkg == i.pkg && it.title == i.title && it.text == i.text }
            items.add(i)
            while (items.size > 15) items.removeAt(0)
        }
    }

    fun last(n: Int): List<Item> = synchronized(items) { items.takeLast(n).reversed() }
    fun clear() = synchronized(items) { items.clear() }
}

class NotifyListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            val n = sbn.notification ?: return
            if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
            val pkg = sbn.packageName
            val messenger = n.category == Notification.CATEGORY_MESSAGE ||
                pkg.contains("viber") || pkg.contains("telegram") || pkg.contains("whatsapp") ||
                pkg.contains("orca") || pkg.contains("messaging") || pkg.contains("mms")
            if (!messenger) return
            val ex = n.extras
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
            if (text.isBlank()) return
            val app = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                pkg
            }
            Inbox.add(Inbox.Item(pkg, app, title, text))
        } catch (e: Exception) {
            // ігноруємо
        }
    }
}
