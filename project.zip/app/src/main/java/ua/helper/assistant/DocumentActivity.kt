package ua.helper.assistant

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

/** Вибір документа чи фото; ШІ читає, переказує або описує його, Арчік озвучує. */
class DocumentActivity : Activity() {
    private lateinit var storage: Storage
    private lateinit var ai: AiClient
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var question: EditText

    private var task = "read"
    private var docText: String? = null
    private var docFile: Pair<String, ByteArray>? = null

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        storage = Storage(this)
        ai = AiClient(storage)
        task = intent.getStringExtra("task") ?: "read"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        root.addView(TextView(this).apply {
            text = if (task == "photo") "Фото й зображення" else "Документ"
            textSize = 22f
            setTextColor(Ui.TEXT)
            typeface = Typeface.DEFAULT_BOLD
        })
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Ui.MUTED)
            text = "Оберіть файл…"
            setPadding(0, dp(6), 0, dp(6))
        }
        root.addView(status)
        result = TextView(this).apply {
            textSize = 16f
            setTextColor(Ui.TEXT)
            setTextIsSelectable(true)
            background = Ui.rounded(this@DocumentActivity, Ui.SURFACE, 16)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        root.addView(ScrollView(this).apply { addView(result) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        question = EditText(this).apply {
            hint = "Запитайте про цей файл…"
            setHintTextColor(Ui.MUTED)
            setTextColor(Ui.TEXT)
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            background = Ui.rounded(this@DocumentActivity, Ui.SURFACE, 24)
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        row.addView(question, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply {
            text = "↑"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = Ui.circleGradient(Ui.ACCENT, Color.parseColor("#2563EB"))
            setOnClickListener { ask() }
        }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(8) })
        root.addView(row)
        setContentView(root)

        if (savedInstanceState == null) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*")
            try {
                startActivityForResult(i, 1)
            } catch (e: Exception) {
                status.text = "Не вдалося відкрити вибір файлу."
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != 1 || resultCode != RESULT_OK || uri == null) {
            status.text = "Файл не обрано."
            return
        }
        status.text = "Читаю файл…"
        Thread {
            try {
                load(uri)
                runOnUiThread { runPrompt(defaultPrompt()) }
            } catch (e: Exception) {
                runOnUiThread { status.text = e.message ?: "Не вдалося прочитати файл." }
            }
        }.start()
    }

    private fun load(uri: Uri) {
        var name = ""
        contentResolver.query(uri, null, null, null, null)?.use {
            if (it.moveToFirst()) {
                val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) name = it.getString(idx) ?: ""
            }
        }
        val mime = contentResolver.getType(uri) ?: ""
        val bytes = contentResolver.openInputStream(uri)?.use { ins ->
            val out = ByteArrayOutputStream()
            val buf = ByteArray(16384)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
                if (out.size() > 15 * 1024 * 1024) throw RuntimeException("Файл завеликий (понад 15 МБ).")
            }
            out.toByteArray()
        } ?: throw RuntimeException("Не вдалося відкрити файл.")
        val lower = name.lowercase()
        docText = null
        docFile = null
        when {
            mime == "application/pdf" || lower.endsWith(".pdf") -> docFile = "application/pdf" to bytes
            mime.startsWith("image/") -> docFile = (if (mime == "image/jpg") "image/jpeg" else mime) to bytes
            lower.endsWith(".docx") || mime.contains("wordprocessingml") -> docText = docx(bytes)
            else -> {
                val s = String(bytes, Charsets.UTF_8)
                val bad = s.take(2000).count { it == '�' || (it.code < 9) }
                if (bad > 20) throw RuntimeException("Цей формат файлу я поки не вмію читати. Підходять PDF, DOCX, TXT і фото.")
                docText = s
            }
        }
        docText = docText?.take(80000)
    }

    private fun docx(bytes: ByteArray): String {
        ZipInputStream(bytes.inputStream()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.name == "word/document.xml") {
                    val xml = String(z.readBytes(), Charsets.UTF_8)
                    return xml.replace("</w:p>", "\n").replace(Regex("<[^>]+>"), "")
                        .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
                        .replace("&quot;", "\"").replace("&apos;", "'")
                }
            }
        }
        throw RuntimeException("Не вдалося прочитати DOCX.")
    }

    private fun defaultPrompt() = when (task) {
        "photo" -> "Опиши, що на цьому зображенні, і прочитай видимий текст."
        "summary" -> "Стисло перекажи основне, чотири-шість речень."
        else -> "Прочитай цей документ: якщо він короткий, передай зміст майже дослівно, " +
            "якщо довгий, викажи головне стисло, до дванадцяти речень."
    }

    private fun ask() {
        val q = question.text.toString().trim()
        if (q.isEmpty() || (docText == null && docFile == null)) return
        question.setText("")
        runPrompt(q)
    }

    private fun runPrompt(prompt: String) {
        status.text = "Думаю…"
        val sys = "Ти Арчік, голосовий помічник. Відповідай ${ai.languageName()} мовою, зв'язним текстом без markdown, " +
            "бо відповідь озвучують голосом."
        val file = docFile
        val text = docText
        val user = if (file != null) prompt else "Документ:\n$text\n\n$prompt"
        ai.generate(sys, user, 3000, file) { out, err ->
            if (out == null) {
                status.text = err ?: "Не вдалося отримати відповідь."
            } else {
                status.text = "Готово"
                result.text = out
                if (AssistantService.running) {
                    try {
                        startService(
                            Intent(this, AssistantService::class.java)
                                .setAction(AssistantService.ACTION_SPEAK)
                                .putExtra("text", out.take(3500))
                        )
                    } catch (e: Exception) {
                        // текст видно на екрані
                    }
                }
            }
        }
    }
}
