package ua.helper.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.ScaleAnimation
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var storage: Storage
    private lateinit var statusText: TextView
    private lateinit var statusDot: View
    private lateinit var powerBtn: PowerSwitch
    private lateinit var chatBox: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var ring: View
    private lateinit var askInput: EditText

    private val handler = Handler(Looper.getMainLooper())
    private var pendingAction: (() -> Unit)? = null
    private var pulsing = false

    private val matchParent = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        storage = Storage(this)
        buildUi()
        if (!storage.permsAsked || intent?.getBooleanExtra("ask_perms", false) == true) {
            storage.permsAsked = true
            askMissingPermissions()
        }
    }

    private fun allRuntimePermissions(): List<String> {
        val l = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.SEND_SMS,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
            LocalMusic.permissionName()
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l
    }

    private fun askMissingPermissions() {
        val missing = allRuntimePermissions().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 20)
    }

    override fun onResume() {
        super.onResume()
        Launcher.appVisible = true
        if (Geo.hasPermission(this)) Thread { try { Geo.refresh(this) } catch (e: Exception) {} }.start()
        AssistantService.logListener = { runOnUiThread { renderChat() } }
        AssistantService.stateListener = { runOnUiThread { refreshState() } }
        refreshState()
        renderChat()
    }

    override fun onPause() {
        Launcher.appVisible = false
        AssistantService.logListener = null
        AssistantService.stateListener = null
        setPulse(false)
        super.onPause()
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    // ---------- інтерфейс ----------

    private lateinit var heroScroll: ScrollView
    private lateinit var heroTitle: TextView
    private lateinit var heroSub: TextView
    private lateinit var heroGlow: View
    private lateinit var heroAvatar: android.widget.ImageView
    private var eyesOpen = false
    private lateinit var waveL: WaveView
    private lateinit var waveR: WaveView

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#0D1A3A"), Color.parseColor("#060B1C"))
            )
        }

        // шапка: меню, назва зі статусом, увімкнення, налаштування
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(6))
        }
        header.addView(
            TextView(this).apply {
                text = "☰"
                textSize = 22f
                gravity = Gravity.CENTER
                setTextColor(Ui.TEXT)
                setOnClickListener { showFunctions() }
            },
            LinearLayout.LayoutParams(dp(44), dp(44))
        )
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        titleCol.addView(TextView(this).apply {
            text = "Арчік"
            textSize = 22f
            setTextColor(Ui.TEXT)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        statusDot = View(this)
        statusRow.addView(statusDot, LinearLayout.LayoutParams(dp(8), dp(8)))
        statusText = TextView(this).apply {
            textSize = 12f
            setTextColor(Ui.MUTED)
        }
        statusRow.addView(statusText, LinearLayout.LayoutParams(wrap, wrap).apply { marginStart = dp(6) })
        titleCol.addView(statusRow)
        header.addView(titleCol, LinearLayout.LayoutParams(0, wrap, 1f))
        powerBtn = PowerSwitch(this).apply {
            setOnClickListener { toggleService() }
        }
        header.addView(powerBtn, LinearLayout.LayoutParams(dp(64), dp(38)).apply { marginEnd = dp(6) })
        header.addView(
            TextView(this).apply {
                text = "⚙"
                textSize = 22f
                gravity = Gravity.CENTER
                setTextColor(Ui.TEXT)
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
                }
            },
            LinearLayout.LayoutParams(dp(44), dp(44))
        )
        root.addView(header)

        // центральна частина: привітальний екран або розмова
        val body = FrameLayout(this)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(8), dp(16), dp(16))
        }
        val avatarFrame = FrameLayout(this)
        heroGlow = GlowRing(this)
        avatarFrame.addView(heroGlow, FrameLayout.LayoutParams(dp(250), dp(250), Gravity.CENTER))
        ring = heroGlow
        heroAvatar = circularAvatar(this, false)
        avatarFrame.addView(heroAvatar, FrameLayout.LayoutParams(dp(190), dp(190), Gravity.CENTER))
        hero.addView(avatarFrame, LinearLayout.LayoutParams(dp(250), dp(250)))
        heroTitle = TextView(this).apply {
            textSize = 24f
            setTextColor(Ui.TEXT)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        hero.addView(heroTitle, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(4) })
        heroSub = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#7FB2FF"))
            gravity = Gravity.CENTER
        }
        hero.addView(heroSub, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(4) })
        hero.addView(
            TextView(this).apply {
                text = "КОРИСНІ ФУНКЦІЇ"
                textSize = 12f
                setTextColor(Ui.MUTED)
                typeface = Typeface.DEFAULT_BOLD
                letterSpacing = 0.12f
            },
            LinearLayout.LayoutParams(matchParent, wrap).apply { topMargin = dp(22); bottomMargin = dp(2) }
        )
        buildFunctionCards(hero)
        heroScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(hero)
        }
        body.addView(heroScroll, FrameLayout.LayoutParams(matchParent, matchParent))

        chatBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(6), dp(14), dp(14))
        }
        chatScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            visibility = View.GONE
            addView(chatBox)
        }
        body.addView(chatScroll, FrameLayout.LayoutParams(matchParent, matchParent))
        root.addView(body, LinearLayout.LayoutParams(matchParent, 0, 1f))

        // мікрофон з хвилями
        val micRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        waveL = WaveView(this)
        waveR = WaveView(this)
        micRow.addView(waveL, LinearLayout.LayoutParams(dp(90), dp(40)))
        val micFrame = FrameLayout(this)
        micFrame.addView(GlowRing(this), FrameLayout.LayoutParams(dp(104), dp(104), Gravity.CENTER))
        micFrame.addView(
            TextView(this).apply {
                text = "🎤"
                textSize = 28f
                gravity = Gravity.CENTER
                background = Ui.circleGradient(Color.parseColor("#12306E"), Color.parseColor("#0A1A40"))
                setOnClickListener { onOrbClick() }
            },
            FrameLayout.LayoutParams(dp(72), dp(72), Gravity.CENTER)
        )
        micRow.addView(micFrame, LinearLayout.LayoutParams(dp(104), dp(104)))
        micRow.addView(waveR, LinearLayout.LayoutParams(dp(90), dp(40)))
        root.addView(micRow)

        // поле введення
        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(2), dp(14), dp(14))
        }
        askInput = EditText(this).apply {
            hint = "Напиши або скажи…"
            setHintTextColor(Ui.MUTED)
            setTextColor(Ui.TEXT)
            textSize = 16f
            background = Ui.rounded(this@MainActivity, Color.parseColor("#14224A"), 26).apply {
                setStroke(dp(1), Color.parseColor("#2A4A99"))
            }
            setPadding(dp(18), dp(12), dp(18), dp(12))
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    sendTyped()
                    true
                } else {
                    false
                }
            }
        }
        inputRow.addView(askInput, LinearLayout.LayoutParams(0, wrap, 1f))
        val send = TextView(this).apply {
            text = "↑"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = Ui.circleGradient(Ui.ACCENT, Color.parseColor("#2563EB"))
            setOnClickListener { sendTyped() }
        }
        inputRow.addView(send, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(10) })
        root.addView(inputRow)

        setContentView(root)
    }

    private data class Fn(val icon: String, val title: String, val sub: String, val cmd: String, val send: Boolean)

    private val functions = listOf(
        Fn("⏰", "Будильник і таймер", "Напр.: постав будильник на 7:30", "постав будильник на ", false),
        Fn("📝", "Нагадування", "Не пропусти важливе", "нагадай мені ", false),
        Fn("📞", "Дзвінки й повідомлення", "Подзвони, напиши у Viber", "подзвони ", false),
        Fn("🔦", "Ліхтарик і гучність", "Увімкни ліхтарик, зроби тихіше", "увімкни ліхтарик", true),
        Fn("📱", "Відкрити програму", "Вайбер, Ютуб, Камера…", "відкрий ", false),
        Fn("🔎", "Пошук і навігація", "Знайди в інтернеті, прокладі маршрут", "знайди ", false),
        Fn("🌤", "Погода", "Де я зараз або в будь-якому місті", "яка погода", true),
        Fn("🚗", "Режим водія", "Арчік діє замість рук", "режим водія", true),
        Fn("🎨", "Намалювати", "Напр.: намалюй кота на місяці", "намалюй ", false),
        Fn("📄", "Документи й фото", "Прочитати, переказати, описати", "прочитай документ", true),
        Fn("🧮", "Математика", "Приклади, задачі, рівняння", "порахуй ", false),
        Fn("💬", "Поговорити", "Запитай пораду чи просто поспілкуйся", "Розкажи щось цікаве", true)
    )

    private fun buildFunctionCards(container: LinearLayout, onPick: (() -> Unit)? = null) {
        for (f in functions) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = Ui.rounded(this@MainActivity, Color.parseColor("#14224A"), 16).apply {
                    setStroke(dp(1), Color.parseColor("#1F3A80"))
                }
                setOnClickListener {
                    onPick?.invoke()
                    if (f.send) {
                        sendToService(AssistantService.ACTION_TEXT, f.cmd)
                    } else {
                        askInput.setText(f.cmd)
                        askInput.setSelection(f.cmd.length)
                        askInput.requestFocus()
                    }
                }
            }
            row.addView(
                TextView(this).apply {
                    text = f.icon
                    textSize = 20f
                    gravity = Gravity.CENTER
                    background = Ui.rounded(this@MainActivity, Color.parseColor("#1B3A85"), 12)
                },
                LinearLayout.LayoutParams(dp(42), dp(42))
            )
            val tc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            tc.addView(TextView(this).apply {
                text = f.title
                textSize = 15f
                setTextColor(Ui.TEXT)
                typeface = Typeface.DEFAULT_BOLD
            })
            tc.addView(TextView(this).apply {
                text = f.sub
                textSize = 12f
                setTextColor(Ui.MUTED)
            })
            row.addView(tc, LinearLayout.LayoutParams(0, wrap, 1f).apply { marginStart = dp(12) })
            row.addView(TextView(this).apply {
                text = "›"
                textSize = 24f
                setTextColor(Ui.MUTED)
            })
            container.addView(row, LinearLayout.LayoutParams(matchParent, wrap).apply { topMargin = dp(8) })
        }
    }

    private fun showFunctions() {
        val dialog = android.app.Dialog(this, android.R.style.Theme_Material_NoActionBar)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(24))
            setBackgroundColor(Color.parseColor("#0A1330"))
        }
        col.addView(TextView(this).apply {
            text = "Що я вмію"
            textSize = 22f
            setTextColor(Ui.TEXT)
            typeface = Typeface.DEFAULT_BOLD
        })
        buildFunctionCards(col) { dialog.dismiss() }
        dialog.setContentView(ScrollView(this).apply { addView(col) })
        dialog.show()
    }

    private fun refreshState() {
        val running = AssistantService.running
        val mode = if (running) AssistantService.mode else "off"
        val (label, color) = when (mode) {
            "wake" -> "Слухає: скажіть «${storage.wakeWord}»" to Ui.GREEN
            "command" -> "Слухаю вас…" to Ui.ACCENT
            "busy" -> "Думаю…" to Ui.AMBER
            "record" -> "Йде запис…" to Color.parseColor("#E5484D")
            "idle" -> "Очікує: торкніться мікрофона" to Ui.GREEN
            else -> if (running) ("Запускаюсь…" to Ui.AMBER) else ("Вимкнено" to Ui.MUTED)
        }
        statusText.text = label
        statusDot.background = Ui.circle(color)
        powerBtn.on = running
        heroTitle.text = when (mode) {
            "command" -> "Слухаю…"
            "busy" -> "Думаю…"
            else -> "Привіт! Я Арчік!"
        }
        heroSub.text = when (mode) {
            "command" -> "Скажи, що потрібно, або постав запитання"
            "wake" -> "Скажи «${storage.wakeWord}» і свою команду"
            "off" -> "Увімкни перемикач угорі або натисни мікрофон, щоб увімкнути мене"
            else -> "Торкнись мікрофона й говори"
        }
        val awake = mode != "off"
        if (awake != eyesOpen) {
            eyesOpen = awake
            heroAvatar.animate().alpha(0.3f).setDuration(130).withEndAction {
                heroAvatar.setImageResource(if (awake) R.drawable.avatar_open else R.drawable.avatar_closed)
                heroAvatar.animate().alpha(1f).setDuration(160).start()
            }.start()
        }
        val listening = mode == "command" || mode == "wake"
        waveL.active = mode == "command"
        waveR.active = mode == "command"
        setPulse(listening)
    }

    private fun setPulse(on: Boolean) {
        if (on == pulsing) return
        pulsing = on
        if (on) {
            val anim = ScaleAnimation(
                0.94f, 1.04f, 0.94f, 1.04f,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f
            ).apply {
                duration = 1300
                repeatCount = Animation.INFINITE
                repeatMode = Animation.REVERSE
            }
            ring.startAnimation(anim)
        } else {
            ring.clearAnimation()
        }
    }

    // ---------- розмова ----------

    private fun renderChat() {
        val lines = synchronized(AssistantService.log) { AssistantService.log.toList() }
        chatBox.removeAllViews()
        val hasChat = lines.any { it.startsWith("Ви: ") || it.startsWith("Арчік: ") }
        heroScroll.visibility = if (hasChat) View.GONE else View.VISIBLE
        chatScroll.visibility = if (hasChat) View.VISIBLE else View.GONE
        if (hasChat) {
            lines.forEach { addBubble(it) }
            chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun addBubble(line: String) {
        val isUser = line.startsWith("Ви: ")
        val isBot = line.startsWith("Арчік: ")
        val text = when {
            isUser -> line.removePrefix("Ви: ")
            isBot -> line.removePrefix("Арчік: ")
            else -> line
        }
        val tv = TextView(this).apply {
            this.text = text
            textSize = if (isUser || isBot) 16f else 12f
            setTextColor(if (isUser) Color.WHITE else if (isBot) Ui.TEXT else Ui.MUTED)
            if (isUser || isBot) {
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = if (isUser) {
                    Ui.gradient(this@MainActivity, Color.parseColor("#2F6BFF"), Color.parseColor("#1D4ED8"), 18)
                } else {
                    Ui.rounded(this@MainActivity, Color.parseColor("#17275A"), 18).apply {
                        setStroke(dp(1), Color.parseColor("#2A4A99"))
                    }
                }
            } else {
                gravity = Gravity.CENTER
            }
        }
        val rowLp = LinearLayout.LayoutParams(matchParent, wrap).apply { topMargin = dp(8) }
        when {
            isUser -> {
                val row = LinearLayout(this).apply { gravity = Gravity.END }
                row.addView(tv, LinearLayout.LayoutParams(wrap, wrap).apply { marginStart = dp(56) })
                chatBox.addView(row, rowLp)
            }
            isBot -> {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.TOP
                }
                row.addView(circularAvatar(this), LinearLayout.LayoutParams(dp(32), dp(32)).apply { marginEnd = dp(8) })
                row.addView(tv, LinearLayout.LayoutParams(wrap, wrap).apply { marginEnd = dp(40) })
                chatBox.addView(row, rowLp)
            }
            else -> chatBox.addView(tv, rowLp)
        }
    }

    // ---------- дії ----------

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun sendTyped() {
        val q = askInput.text.toString().trim()
        if (q.isNotEmpty()) {
            askInput.setText("")
            sendToService(AssistantService.ACTION_TEXT, q)
        }
    }

    private fun onOrbClick() {
        if (Recorder.active) {
            sendToService(AssistantService.ACTION_STOP_RECORD, null)
        } else if (AssistantService.running) {
            sendToService(AssistantService.ACTION_LISTEN, null)
        } else {
            sendToService(AssistantService.ACTION_START, null)
        }
    }

    private fun toggleService() {
        if (AssistantService.running) {
            startService(Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_STOP))
            handler.postDelayed({ refreshState() }, 600)
        } else {
            sendToService(AssistantService.ACTION_START, null)
        }
    }

    private fun sendToService(action: String, text: String?) {
        ensurePermissions {
            val i = Intent(this, AssistantService::class.java).setAction(action)
            if (text != null) i.putExtra("text", text)
            try {
                if (AssistantService.running) startService(i) else startForegroundService(i)
            } catch (e: Exception) {
                toast("Не вдалося запустити Арчіка: ${e.message}")
            }
            handler.postDelayed({ refreshState() }, 700)
        }
    }

    // ---------- дозволи ----------

    private fun ensurePermissions(then: () -> Unit) {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isEmpty()) {
            then()
        } else {
            pendingAction = then
            requestPermissions(need.toTypedArray(), 10)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) {
            val action = pendingAction
            pendingAction = null
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                action?.invoke()
            } else {
                toast("Без дозволу на мікрофон Арчік не працює.")
            }
        }
    }
}
