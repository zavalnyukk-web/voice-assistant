package ua.helper.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.net.Uri
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var storage: Storage
    private lateinit var statusView: TextView
    private lateinit var toggleBtn: Button
    private lateinit var logView: TextView
    private lateinit var askInput: EditText
    private lateinit var wakeSwitch: Switch
    private lateinit var wakeWordInput: EditText
    private lateinit var keyInput: EditText

    private val handler = Handler(Looper.getMainLooper())
    private var pendingAction: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        storage = Storage(this)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        Launcher.appVisible = true
        AssistantService.logListener = { runOnUiThread { renderLog() } }
        refreshState()
        renderLog()
    }

    override fun onPause() {
        Launcher.appVisible = false
        AssistantService.logListener = null
        super.onPause()
    }

    // ---------- інтерфейс ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val pad = dp(16)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun add(v: View, gap: Int = 8) {
            col.addView(
                v,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(gap) }
            )
        }

        fun label(text: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
            this.text = text
            textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        fun button(text: String, onClick: () -> Unit) = Button(this).apply {
            this.text = text
            isAllCaps = false
            setOnClickListener { onClick() }
        }

        col.addView(
            ImageView(this).apply { setImageResource(R.mipmap.ic_launcher_foreground) },
            LinearLayout.LayoutParams(dp(170), dp(170)).apply { gravity = Gravity.CENTER_HORIZONTAL }
        )
        add(label("Арчік", 28f, true), 0)

        statusView = label("", 15f)
        add(statusView)

        toggleBtn = button("Запустити Арчіка") { toggleService() }
        add(toggleBtn)

        add(button("🎤 Сказати зараз") {
            sendToService(AssistantService.ACTION_LISTEN, null)
        })

        askInput = EditText(this).apply {
            hint = "Або напишіть запитання чи команду"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        add(askInput, 16)
        add(button("Надіслати") {
            val q = askInput.text.toString().trim()
            if (q.isNotEmpty()) {
                askInput.setText("")
                sendToService(AssistantService.ACTION_TEXT, q)
            }
        })

        add(label("Розмова", 18f, true), 20)
        logView = label("", 15f)
        add(logView)

        add(label("Налаштування", 18f, true), 24)

        wakeSwitch = Switch(this).apply {
            text = "Активація словом (слухати постійно)"
            isChecked = storage.wakeEnabled
        }
        add(wakeSwitch)

        wakeWordInput = EditText(this).apply {
            hint = "Слово-активація"
            setText(storage.wakeWord)
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        add(wakeWordInput)

        keyInput = EditText(this).apply {
            hint = "Ключ для відповідей ШІ (Gemini безкоштовно)"
            setText(storage.apiKey)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }
        add(keyInput)

        add(button("Зберегти налаштування") { saveSettings() })
        add(button("Мої нотатки, покупки, нагадування") { showData() })

        add(label("Дозволи для керування телефоном", 18f, true), 24)
        add(button("Дозволити контакти й дзвінки") { requestContactsCalls() })
        add(button("Дозволити відкривати програми з фону") { openOverlaySettings() })
        add(button("Не обмежувати батарею (щоб працював у фоні)") {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                toast("Відкрийте налаштування батареї вручну.")
            }
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun renderLog() {
        val lines = synchronized(AssistantService.log) { AssistantService.log.toList() }
        logView.text = if (lines.isEmpty()) {
            "Тут з'являтиметься розмова."
        } else {
            lines.asReversed().joinToString("\n\n")
        }
    }

    private fun refreshState() {
        val running = AssistantService.running
        toggleBtn.text = if (running) "Зупинити Арчіка" else "Запустити Арчіка"
        statusView.text = when {
            !running -> "Зупинено."
            storage.wakeEnabled -> "Працює. Скажіть «${storage.wakeWord}» і потім команду."
            else -> "Працює. Натисніть «Сказати зараз» або «Слухати» у сповіщенні."
        }
    }

    // ---------- дії ----------

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun toggleService() {
        if (AssistantService.running) {
            startService(Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_STOP))
            handler.postDelayed({ refreshState() }, 600)
        } else {
            sendToService(AssistantService.ACTION_START, null)
        }
    }

    private fun sendToService(action: String, text: String?) {
        ensurePermissions {
            val i = Intent(this, AssistantService::class.java).setAction(action)
            if (text != null) i.putExtra("text", text)
            try {
                if (AssistantService.running) startService(i) else startForegroundService(i)
            } catch (e: Exception) {
                toast("Не вдалося запустити помічника: ${e.message}")
            }
            handler.postDelayed({ refreshState() }, 700)
        }
    }

    private fun saveSettings() {
        storage.wakeEnabled = wakeSwitch.isChecked
        storage.wakeWord = wakeWordInput.text.toString()
        storage.apiKey = keyInput.text.toString()
        wakeWordInput.setText(storage.wakeWord)
        if (AssistantService.running) {
            startService(Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_RELOAD))
        }
        refreshState()
        toast("Збережено.")
    }

    private fun showData() {
        val notes = storage.getList("notes")
        val shopping = storage.getList("shopping")
        val reminders = storage.getReminders().sortedBy { it.time }
        val fmt = SimpleDateFormat("d MMMM, HH:mm", Locale("uk", "UA"))
        val sb = StringBuilder()
        sb.append("Нотатки:\n")
        if (notes.isEmpty()) sb.append("— порожньо\n") else notes.forEach { sb.append("• ").append(it).append("\n") }
        sb.append("\nСписок покупок:\n")
        if (shopping.isEmpty()) sb.append("— порожньо\n") else shopping.forEach { sb.append("• ").append(it).append("\n") }
        sb.append("\nНагадування:\n")
        if (reminders.isEmpty()) {
            sb.append("— немає\n")
        } else {
            reminders.forEach { sb.append("• ").append(fmt.format(Date(it.time))).append(" — ").append(it.text).append("\n") }
        }
        AlertDialog.Builder(this)
            .setTitle("Мої дані")
            .setMessage(sb.toString())
            .setPositiveButton("Ок", null)
            .show()
    }

    // ---------- дозволи ----------

    private fun requestContactsCalls() {
        requestPermissions(
            arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE), 11
        )
    }

    private fun openOverlaySettings() {
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            toast("Відкрийте налаштування вручну: Програми → Арчік → Поверх інших вікон.")
        }
    }

    private fun ensurePermissions(then: () -> Unit) {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isEmpty()) {
            then()
        } else {
            pendingAction = then
            requestPermissions(need.toTypedArray(), 10)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) {
            val action = pendingAction
            pendingAction = null
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                action?.invoke()
            } else {
                toast("Без дозволу на мікрофон помічник не працює.")
            }
        }
    }
}
