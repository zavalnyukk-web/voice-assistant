package ua.helper.assistant

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Власний диктофон Арчіка: запис голосу в файл m4a. */
object Recorder {
    private var rec: MediaRecorder? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null
    private var file: File? = null
    private var name = ""
    private val handler = Handler(Looper.getMainLooper())
    var onAutoStop: (() -> Unit)? = null

    val active: Boolean get() = rec != null

    @Suppress("DEPRECATION")
    private fun newRecorder(ctx: Context): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()

    /** Повертає null, якщо все гаразд, інакше текст помилки. */
    fun start(c: Context, maxMs: Long): String? {
        if (rec != null) return "Запис уже йде."
        val ctx = c.applicationContext
        name = "Запис_" + SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
        try {
            val r = newRecorder(ctx)
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128000)
            r.setAudioSamplingRate(44100)
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Audio.Media.DISPLAY_NAME, "$name.m4a")
                    put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                    put(MediaStore.Audio.Media.IS_PENDING, 1)
                    val dir = if (Build.VERSION.SDK_INT >= 31) Environment.DIRECTORY_RECORDINGS else Environment.DIRECTORY_MUSIC
                    put(MediaStore.Audio.Media.RELATIVE_PATH, "$dir/Арчік")
                }
                val u = ctx.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v)
                    ?: return "Не вдалося створити файл запису."
                uri = u
                val p = ctx.contentResolver.openFileDescriptor(u, "w") ?: return "Не вдалося відкрити файл запису."
                pfd = p
                r.setOutputFile(p.fileDescriptor)
            } else {
                val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: ctx.filesDir
                val f = File(dir, "$name.m4a")
                file = f
                r.setOutputFile(f.absolutePath)
            }
            r.prepare()
            r.start()
            rec = r
            handler.postDelayed({ onAutoStop?.invoke() }, maxMs)
            return null
        } catch (e: Exception) {
            cleanup()
            return "Не вдалося почати запис: " + (e.message ?: "помилка мікрофона")
        }
    }

    /** Зупиняє запис і повертає ім'я файлу, або null, якщо запису не було. */
    fun stop(c: Context): String? {
        val r = rec ?: return null
        handler.removeCallbacksAndMessages(null)
        try {
            r.stop()
        } catch (e: Exception) {
            // дуже короткий запис
        }
        try {
            r.release()
        } catch (e: Exception) {
        }
        rec = null
        try {
            pfd?.close()
        } catch (e: Exception) {
        }
        pfd = null
        val u = uri
        if (u != null && Build.VERSION.SDK_INT >= 29) {
            try {
                val v = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
                c.contentResolver.update(u, v, null, null)
                Storage(c).lastRecording = ContentUris.parseId(u)
            } catch (e: Exception) {
            }
        }
        uri = null
        file = null
        return "$name.m4a"
    }

    private fun cleanup() {
        try {
            rec?.release()
        } catch (e: Exception) {
        }
        rec = null
        try {
            pfd?.close()
        } catch (e: Exception) {
        }
        pfd = null
    }
}
