package ua.helper.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Місцезнаходження: беремо останнє відоме і запам'ятовуємо для використання у фоні. */
object Geo {
    fun hasPermission(c: Context) =
        c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Викликати з фонового потоку. */
    fun locate(c: Context, allowFresh: Boolean): Location? {
        if (!hasPermission(c)) return null
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        try {
            for (p in lm.getProviders(true)) {
                val l = try {
                    lm.getLastKnownLocation(p)
                } catch (e: SecurityException) {
                    null
                }
                if (l != null && (best == null || l.time > best.time)) best = l
            }
            val fresh = best != null && System.currentTimeMillis() - best.time < 2 * 3600 * 1000L
            if (!fresh && allowFresh && Build.VERSION.SDK_INT >= 30) {
                val provider = when {
                    lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                    lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                    else -> null
                }
                if (provider != null) {
                    val latch = CountDownLatch(1)
                    var got: Location? = null
                    lm.getCurrentLocation(provider, null, java.util.concurrent.Executor { it.run() }) { loc ->
                        got = loc
                        latch.countDown()
                    }
                    latch.await(8, TimeUnit.SECONDS)
                    if (got != null) best = got
                }
            }
        } catch (e: Exception) {
            // повертаємо те, що є
        }
        return best
    }

    fun refresh(c: Context) {
        val l = locate(c, true) ?: return
        val st = Storage(c)
        st.geoLat = l.latitude
        st.geoLon = l.longitude
    }
}

/** Додаткові вміння: погода, математика, малюнки, документи й фото. */
class Skills(
    private val context: Context,
    private val storage: Storage,
    private val ai: AiClient
) {
    private val uk = Locale("uk", "UA")
    private val main = Handler(Looper.getMainLooper())

    /** Повертає true, якщо команду взято в роботу; відповідь прийде через done(текст, слухатиДалі). */
    fun tryHandle(raw: String, done: (String, Boolean) -> Unit): Boolean {
        val lower = raw.lowercase(uk).replace("'", "").replace("’", "").replace("ʼ", "").trim()
        val t = lower.replace(Regex("[,.!?;:]"), " ").replace(Regex("\\s+"), " ").trim()
        return when {
            isWeather(t) -> {
                weather(t, done)
                true
            }
            isDraw(t) -> {
                draw(t, done)
                true
            }
            isDocument(t) -> {
                document(t, done)
                true
            }
            isMath(t, lower) -> {
                math(t, lower, done)
                true
            }
            else -> false
        }
    }

    private fun has(t: String, vararg w: String) = w.any { t.contains(it) }
    private fun reply(done: (String, Boolean) -> Unit, text: String, follow: Boolean = false) {
        main.post { done(text, follow) }
    }

    // ---------- погода ----------

    private fun isWeather(t: String) =
        has(t, "погод", "парасол", "скільки градусів", "яка температура", "чи буде дощ", "чи буде сніг",
            "чи йтиме дощ", "чи йтиме сніг", "що там надворі", "яка надворі")

    private val notCity = setOf(
        "сьогодні", "завтра", "післязавтра", "зараз", "мене", "нас", "тут", "дворі", "вулиці", "місті",
        "моєму", "нашому", "мому", "найближчі", "цей", "ці", "тиждень", "вихідні", "неділю", "суботу"
    )

    private fun extractCity(t: String): String? {
        val m = Regex("(?:^| )(?:в|у|для|по|біля|під) ([а-яіїєґ\\-]{3,}(?: [а-яіїєґ\\-]{3,})?)").find(t) ?: return null
        val words = m.groupValues[1].split(" ").filter { it !in notCity }
        if (words.isEmpty()) return null
        return words.first()
    }

    private fun http(url: String, headers: Map<String, String> = emptyMap()): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 12000
            c.readTimeout = 15000
            for ((k, v) in headers) c.setRequestProperty(k, v)
            val code = c.responseCode
            if (code !in 200..299) throw RuntimeException("HTTP $code")
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun weather(t: String, done: (String, Boolean) -> Unit) {
        Thread {
            try {
                val day = when {
                    t.contains("післязавтра") -> 2
                    t.contains("завтра") -> 1
                    else -> 0
                }
                val city = extractCity(t)
                var lat: Double
                var lon: Double
                var place: String
                if (city != null) {
                    val g = geocode(city)
                    if (g == null) {
                        reply(done, "Не знайшов місто «$city». Назвіть його ще раз у називному відмінку.")
                        return@Thread
                    }
                    lat = g.first
                    lon = g.second
                    place = g.third
                } else {
                    if (!Geo.hasPermission(context)) {
                        reply(done, "Щоб розповісти погоду там, де ви є, дайте доступ до місцезнаходження в налаштуваннях Арчіка. Або назвіть місто.")
                        return@Thread
                    }
                    val loc = Geo.locate(context, true)
                    if (loc != null) {
                        lat = loc.latitude
                        lon = loc.longitude
                        storage.geoLat = lat
                        storage.geoLon = lon
                    } else if (!storage.geoLat.isNaN() && !storage.geoLon.isNaN()) {
                        lat = storage.geoLat
                        lon = storage.geoLon
                    } else {
                        reply(done, "Не вдалося визначити, де ви. Увімкніть геолокацію на телефоні, відкрийте Арчіка й спробуйте ще раз, або назвіть місто.")
                        return@Thread
                    }
                    place = placeName(lat, lon)
                }

                val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m" +
                    "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max" +
                    "&timezone=auto&forecast_days=3&wind_speed_unit=ms"
                val j = JSONObject(http(url))
                val cur = j.getJSONObject("current")
                val d = j.getJSONObject("daily")
                val maxT = Math.round(d.getJSONArray("temperature_2m_max").getDouble(day)).toInt()
                val minT = Math.round(d.getJSONArray("temperature_2m_min").getDouble(day)).toInt()
                val rain = d.getJSONArray("precipitation_probability_max").optInt(day, 0)
                val dayCode = d.getJSONArray("weather_code").getInt(day)
                val wind = Math.round(d.getJSONArray("wind_speed_10m_max").getDouble(day)).toInt()
                val head = if (place.isEmpty()) "Погода." else "Погода: $place."
                val text = if (day == 0) {
                    val now = Math.round(cur.getDouble("temperature_2m")).toInt()
                    val feel = Math.round(cur.getDouble("apparent_temperature")).toInt()
                    val w = Math.round(cur.getDouble("wind_speed_10m")).toInt()
                    "$head Зараз ${deg(now)}, відчувається як ${deg(feel)}, ${describe(cur.getInt("weather_code"))}. " +
                        "Вітер $w м/с. Сьогодні від ${deg(minT)} до ${deg(maxT)}, ймовірність опадів $rain відсотків."
                } else {
                    val name = if (day == 1) "Завтра" else "Післязавтра"
                    "$head $name від ${deg(minT)} до ${deg(maxT)}, ${describe(dayCode)}. " +
                        "Ймовірність опадів $rain відсотків, вітер до $wind м/с."
                }
                reply(done, text)
            } catch (e: Exception) {
                reply(done, "Не вдалося отримати погоду. Перевірте інтернет.")
            }
        }.start()
    }

    private fun geocode(name: String): Triple<Double, Double, String>? {
        val cands = mutableListOf(name)
        for (cut in 1..3) if (name.length - cut >= 3) cands.add(name.dropLast(cut))
        for (c in cands) {
            try {
                val j = JSONObject(
                    http(
                        "https://geocoding-api.open-meteo.com/v1/search?name=" +
                            URLEncoder.encode(c, "UTF-8") + "&count=1&language=uk&format=json"
                    )
                )
                val r = j.optJSONArray("results")?.optJSONObject(0) ?: continue
                return Triple(r.getDouble("latitude"), r.getDouble("longitude"), r.optString("name", name))
            } catch (e: Exception) {
                // пробуємо наступний варіант
            }
        }
        return null
    }

    @Suppress("DEPRECATION")
    private fun placeName(lat: Double, lon: Double): String {
        try {
            if (android.location.Geocoder.isPresent()) {
                val a = android.location.Geocoder(context, uk).getFromLocation(lat, lon, 1)
                val x = a?.firstOrNull()
                val n = x?.locality ?: x?.subAdminArea ?: x?.adminArea
                if (!n.isNullOrBlank()) {
                    storage.geoPlace = n
                    return n
                }
            }
        } catch (e: Exception) {
            // пробуємо інший спосіб
        }
        try {
            val j = JSONObject(
                http(
                    "https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=10&accept-language=uk&lat=$lat&lon=$lon",
                    mapOf("User-Agent" to "ArchikAssistant/1.0")
                )
            )
            val a = j.optJSONObject("address")
            val n = a?.optString("city").orEmpty().ifEmpty { a?.optString("town").orEmpty() }
                .ifEmpty { a?.optString("village").orEmpty() }
                .ifEmpty { a?.optString("county").orEmpty() }
            if (n.isNotBlank()) {
                storage.geoPlace = n
                return n
            }
        } catch (e: Exception) {
            // без назви
        }
        return storage.geoPlace
    }

    private fun deg(n: Int): String {
        val a = Math.abs(n)
        val word = when {
            a % 100 in 11..14 -> "градусів"
            a % 10 == 1 -> "градус"
            a % 10 in 2..4 -> "градуси"
            else -> "градусів"
        }
        return (if (n < 0) "мінус $a" else if (n > 0) "плюс $a" else "0") + " " + word
    }

    private fun describe(code: Int) = when (code) {
        0 -> "ясно"
        1 -> "переважно ясно"
        2 -> "мінлива хмарність"
        3 -> "хмарно"
        45, 48 -> "туман"
        51, 53, 55, 56, 57 -> "мряка"
        61, 63 -> "дощ"
        65 -> "сильний дощ"
        66, 67 -> "крижаний дощ"
        71, 73 -> "сніг"
        75, 77 -> "сильний сніг"
        80, 81 -> "короткочасний дощ"
        82 -> "злива"
        85, 86 -> "снігопад"
        95 -> "гроза"
        96, 99 -> "гроза з градом"
        else -> "мінлива погода"
    }

    // ---------- математика ----------

    private fun isMath(t: String, lower: String): Boolean {
        if (t.startsWith("порахуй") || t.startsWith("пораху") || t.startsWith("обчисли") ||
            t.startsWith("розвяжи") || t.startsWith("розвязати") || t.startsWith("розвязуй") ||
            t.startsWith("скільки буде") || t.startsWith("скільки це") ||
            t.startsWith("вирішити приклад") || t.startsWith("знайди корінь") ||
            t.startsWith("реши") || t.contains("рівнянн") || t.contains("розвяжи задач")
        ) return true
        return lower.matches(Regex("[0-9+\\-*/^().,%xх×÷\\s]+")) && lower.any { it.isDigit() } &&
            lower.any { it in "+-*/^×÷xх%" }
    }

    private fun math(t: String, lower: String, done: (String, Boolean) -> Unit) {
        val local = try {
            evalMath(lower)
        } catch (e: ArithmeticException) {
            reply(done, "Ділити на нуль не можна.")
            return
        } catch (e: Exception) {
            null
        }
        if (local != null) {
            reply(done, "Відповідь: ${fmt(local)}.")
            return
        }
        if (storage.apiKey.isBlank()) {
            reply(done, "Для складних задач потрібен ключ штучного інтелекту. Додайте його в налаштуваннях.")
            return
        }
        val sys = "Ти терплячий репетитор з математики. Розв'яжи завдання крок за кроком, але стисло. " +
            "Формули пиши словами, зрозумілими на слух (наприклад «ікс у квадраті»), без LaTeX і markdown. " +
            "Наприкінці чітко назви відповідь. Відповідай ${ai.languageName()} мовою."
        ai.generate(sys, lower, 2500) { text, err -> done(text ?: err ?: "Не вдалося розв'язати.", false) }
    }

    private fun fmt(v: Double): String {
        if (v.isNaN() || v.isInfinite()) return "не визначено"
        if (v == Math.rint(v) && Math.abs(v) < 1e15) return v.toLong().toString()
        val s = String.format(Locale.US, "%.6f", v).trimEnd('0').trimEnd('.')
        return s.replace('.', ',')
    }

    private fun evalMath(src: String): Double? {
        var s = src
        for (w in listOf("порахуй", "обчисли", "розвяжи", "розвязати", "розвязуй", "скільки буде", "скільки це",
            "вирішити приклад", "приклад", "реши")) s = s.replace(w, " ")
        s = s.replace(
            Regex("(\\d+(?:[.,]\\d+)?)\\s*(?:%|відсотк\\S*|процент\\S*)\\s*від\\s*(\\d+(?:[.,]\\d+)?)")
        ) { m -> "(${m.groupValues[1]}/100*${m.groupValues[2]})" }
        s = s.replace(Regex("корінь(?: квадратний)?\\s*(?:з|із|від)?\\s*(\\d+(?:[.,]\\d+)?)")) {
            "sqrt(${it.groupValues[1]})"
        }
        for ((a, b) in listOf(
            "помножити на" to "*", "помножене на" to "*", "множене на" to "*", "помножити" to "*",
            "поділити на" to "/", "розділити на" to "/", "ділене на" to "/", "поділене на" to "/",
            "плюс" to "+", "мінус" to "-", "у квадраті" to "^2", "в квадраті" to "^2",
            "у кубі" to "^3", "в кубі" to "^3", "у степені" to "^", "в степені" to "^", "×" to "*", "÷" to "/"
        )) s = s.replace(a, b)
        s = s.replace(Regex("(?<=\\d)\\s*[xх]\\s*(?=\\d)"), "*")
        s = s.replace(',', '.').replace("?", " ").trim()
        if (s.isEmpty()) return null
        if (!s.replace("sqrt", "").matches(Regex("[0-9+\\-*/^().\\s]+"))) return null
        return Parser(s).parse()
    }

    private class Parser(val s: String) {
        var i = 0
        fun ws() {
            while (i < s.length && s[i].isWhitespace()) i++
        }

        fun parse(): Double {
            val v = expr()
            ws()
            if (i != s.length) throw IllegalArgumentException("зайве")
            return v
        }

        fun expr(): Double {
            var v = term()
            while (true) {
                ws()
                if (i < s.length && s[i] == '+') {
                    i++
                    v += term()
                } else if (i < s.length && s[i] == '-') {
                    i++
                    v -= term()
                } else return v
            }
        }

        fun term(): Double {
            var v = power()
            while (true) {
                ws()
                if (i < s.length && s[i] == '*') {
                    i++
                    v *= power()
                } else if (i < s.length && s[i] == '/') {
                    i++
                    val d = power()
                    if (d == 0.0) throw ArithmeticException()
                    v /= d
                } else return v
            }
        }

        fun power(): Double {
            val b = unary()
            ws()
            if (i < s.length && s[i] == '^') {
                i++
                return Math.pow(b, power())
            }
            return b
        }

        fun unary(): Double {
            ws()
            if (i < s.length && s[i] == '-') {
                i++
                return -unary()
            }
            if (i < s.length && s[i] == '+') {
                i++
                return unary()
            }
            return atom()
        }

        fun atom(): Double {
            ws()
            if (s.startsWith("sqrt", i)) {
                i += 4
                ws()
                val v = atom()
                return Math.sqrt(v)
            }
            if (i < s.length && s[i] == '(') {
                i++
                val v = expr()
                ws()
                if (i >= s.length || s[i] != ')') throw IllegalArgumentException("дужка")
                i++
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalArgumentException("число")
            return s.substring(st, i).toDouble()
        }
    }

    // ---------- малюнки ----------

    private fun isDraw(t: String) =
        t.startsWith("намалюй") || t.startsWith("нарисуй") || t.startsWith("малюй") ||
            has(t, "створи малюнок", "створи зображення", "створи картинку", "згенеруй зображення",
                "згенеруй малюнок", "згенеруй картинку", "зроби малюнок", "намалювати")

    private fun draw(t: String, done: (String, Boolean) -> Unit) {
        if (storage.apiKey.isBlank()) {
            reply(done, "Щоб малювати, додайте ключ штучного інтелекту в налаштуваннях.")
            return
        }
        var subject = t
        for (w in listOf("намалюй", "нарисуй", "малюй", "створи малюнок", "створи зображення", "створи картинку",
            "згенеруй зображення", "згенеруй малюнок", "згенеруй картинку", "зроби малюнок", "мені", "будь ласка")) {
            subject = subject.replace(w, " ")
        }
        subject = subject.replace(Regex("\\s+"), " ").trim()
        if (subject.isEmpty()) {
            reply(done, "Що намалювати? Наприклад: намалюй кота на місяці.", true)
            return
        }
        main.post { AssistantService.addLog("Малюю: $subject…") }
        val sys = "Ти талановитий ілюстратор. Відповідай ТІЛЬКИ одним SVG-кодом від <svg до </svg>, без пояснень " +
            "і без markdown. Використовуй viewBox=\"0 0 800 800\", насичені кольори, градієнти, фон, " +
            "чітку композицію й дрібні деталі. Без скриптів, без зовнішніх посилань і без растрових картинок."
        ai.generate(sys, "Намалюй: $subject", 7000) { text, err ->
            if (text == null) {
                done(err ?: "Не вдалося намалювати.", false)
                return@generate
            }
            val svg = extractSvg(text)
            if (svg == null) {
                done("Не вийшло намалювати. Спробуйте описати простіше.", false)
                return@generate
            }
            try {
                val f = File(context.cacheDir, "draw_${System.currentTimeMillis()}.svg")
                f.writeText(svg)
                val i = Intent(context, DrawingActivity::class.java)
                    .putExtra("path", f.absolutePath).putExtra("title", subject)
                val shown = Launcher.start(context, i, "Малюнок: $subject")
                done(
                    if (shown) "Готово, малюнок на екрані." else "Малюнок готовий. Натисніть сповіщення, щоб його відкрити.",
                    false
                )
            } catch (e: Exception) {
                done("Не вдалося зберегти малюнок.", false)
            }
        }
    }

    private fun extractSvg(text: String): String? {
        val a = text.indexOf("<svg")
        val b = text.lastIndexOf("</svg>")
        if (a < 0 || b < 0 || b < a) return null
        var svg = text.substring(a, b + 6)
        svg = svg.replace(Regex("(?is)<script.*?</script>"), "")
            .replace(Regex("(?i)\\son\\w+\\s*=\\s*(\"[^\"]*\"|'[^']*')"), "")
            .replace(Regex("(?i)(xlink:)?href\\s*=\\s*(\"https?:[^\"]*\"|'https?:[^']*')"), "")
            .replace("javascript:", "")
        return svg
    }

    // ---------- документи й фото ----------

    private fun isDocument(t: String) =
        has(t, "прочитай документ", "прочитай файл", "прочитай мені документ", "перекажи документ",
            "перекажи файл", "відкрий документ", "що в документі", "що у документі", "прочитай pdf",
            "прочитай пдф", "що на фото", "що на зображенні", "що на картинці", "опиши фото",
            "опиши зображення", "опиши картинку", "прочитай текст з фото", "прочитай фото")

    private fun document(t: String, done: (String, Boolean) -> Unit) {
        if (storage.apiKey.isBlank()) {
            reply(done, "Щоб читати документи й фото, додайте ключ штучного інтелекту в налаштуваннях.")
            return
        }
        val task = when {
            has(t, "що на фото", "що на зображенні", "що на картинці", "опиши фото", "опиши зображення", "опиши картинку") -> "photo"
            has(t, "перекажи") -> "summary"
            else -> "read"
        }
        val i = Intent(context, DocumentActivity::class.java).putExtra("task", task)
        val shown = Launcher.start(context, i, "Обрати файл")
        reply(
            done,
            if (shown) "Оберіть файл на екрані." else "Натисніть сповіщення, щоб обрати файл."
        )
    }
}
