package ua.helper.assistant

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Відповіді ШІ. Провайдер визначається за ключем:
 *  - ключ, що починається з "sk-ant-", це Claude (платний);
 *  - будь-який інший (зазвичай "AIza..."), це Google Gemini (є безкоштовний рівень).
 */
class AiClient(private val storage: Storage) {

    companion object {
        private const val CLAUDE_MODEL = "claude-haiku-5-5"
        private const val CLAUDE_URL = "https://api.anthropic.com/v1/messages"
        private const val GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models/"

        // Якщо одна модель перевантажена (503) або вичерпала ліміт (429), пробуємо наступну.
        private val GEMINI_MODELS =
            listOf("gemini-flash-latest", "gemini-flash-lite-latest", "gemini-2.5-flash")
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val history = mutableListOf<Pair<String, String>>() // ("user"|"assistant", текст)

    fun ask(question: String, callback: (String) -> Unit) {
        Thread {
            val answer = try {
                if (storage.apiKey.startsWith("sk-ant-")) requestClaude(question) else requestGemini(question)
            } catch (e: Exception) {
                "Не вдалося отримати відповідь. Перевірте інтернет і ключ."
            }
            mainHandler.post { callback(answer) }
        }.start()
    }

    /** Пошук в інтернеті сильно сповільнює відповідь, тому вмикаємо його лише коли потрібні свіжі дані. */
    private val searchRe = Regex(
        "новин|курс |курси|ціна|ціни|скільки коштує|вартість|сьогодні|зараз |вчора|завтра|останні|останній|" +
            "нещодавно|хто виграв|рахунок|матч|чемпіонат|вибори|президент|прем.єр|міністр|20(2[4-9]|3\\d)|" +
            "актуальн|сучасн|де купити|коли вийде|вийшов|прогноз|біржа|біткоїн|долар|євро|акції|що відбувається|що сталося|знайди в інтернеті|загугли|пошукай"
    )

    private fun needsSearch(q: String): Boolean = searchRe.containsMatchIn(q.lowercase(Locale("uk", "UA")))

    private fun system(): String {
        val now = SimpleDateFormat("d MMMM yyyy, EEEE, HH:mm", Locale("uk", "UA")).format(Date())
        return "Ти Арчік: голосовий помічник у смартфоні і добрий співрозмовник. " +
            "Відповідай виключно ${Languages.find(storage.ttsLang).adjective} мовою. Говори тепло й невимушено, як друг. " +
            "Відповідай живою мовою, зазвичай одним-трьома короткими реченнями, без списків, markdown, емодзі й спецсимволів, " +
            "бо твою відповідь озвучують голосом. Можеш поставити одне коротке запитання у відповідь, щоб підтримати розмову, " +
            "і давати поради. У питаннях здоров'я, грошей чи права давай обережні загальні поради " +
            "й раджай звернутися до фахівця, коли це справді важливо. " +
            "Для актуальних даних (новини, курси валют, ціни, спорт, події, факти після 2024 року) користуйся пошуком в інтернеті " +
            "й коротко називай джерело; якщо пошук не дав відповіді, чесно скажи про це. " +
            "Поточна дата й час користувача: $now."
    }

    private fun remember(question: String, answer: String) {
        synchronized(history) {
            history.add("user" to question)
            history.add("assistant" to answer)
            while (history.size > 16) {
                history.removeAt(0)
                history.removeAt(0)
            }
        }
    }

    private fun post(
        url: String, headers: Map<String, String>, body: JSONObject, readTimeoutMs: Int = 40000
    ): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = readTimeoutMs
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return code to text
        } finally {
            conn.disconnect()
        }
    }

    /** Як post, але таймаут чи збій мережі дають код 503, щоб спробувати іншу модель, а не зависати. */
    private fun postSafe(url: String, key: String, body: JSONObject, timeout: Int): Pair<Int, String> =
        try {
            post(url, mapOf("x-goog-api-key" to key), body, timeout)
        } catch (e: java.io.IOException) {
            503 to ""
        }

    private fun logDetails(provider: String, code: Int, body: String) {
        val msg = try {
            JSONObject(body).getJSONObject("error").optString("message")
        } catch (e: Exception) {
            body
        }
        mainHandler.post { AssistantService.addLog("$provider, код $code: ${msg.take(300)}") }
    }

    private fun errorMessage(code: Int): String? = when (code) {
        400, 401, 403 -> "Ключ не підійшов або немає доступу. Перевірте ключ у налаштуваннях."
        404 -> "Модель ШІ недоступна. Напишіть розробнику."
        429 -> "Ліміт запитів вичерпано. Спробуйте за хвилину або пізніше."
        in 500..599 -> "Сервіс ШІ тимчасово недоступний. Спробуйте пізніше."
        else -> if (code in 200..299) null else "Сервіс ШІ повернув помилку $code."
    }

    // ---------- Claude ----------

    private fun requestClaude(question: String): String {
        val messages = JSONArray()
        val snapshot = synchronized(history) { history.toList() }
        for ((role, text) in snapshot) {
            messages.put(JSONObject().put("role", role).put("content", text))
        }
        messages.put(JSONObject().put("role", "user").put("content", question))

        val body = JSONObject()
            .put("model", CLAUDE_MODEL)
            .put("max_tokens", 400)
            .put("system", system())
            .put("messages", messages)
        val search = needsSearch(question)
        if (search) {
            body.put(
                "tools",
                JSONArray().put(
                    JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 2)
                )
            )
        }

        val headers = mapOf("x-api-key" to storage.apiKey, "anthropic-version" to "2023-06-01")
        var (code, text) = post(CLAUDE_URL, headers, body, if (search) 30000 else 20000)
        if (code !in 200..299 && code != 401 && code != 403 && code != 429) {
            // пошук недоступний для цього ключа: відповідаємо без нього
            body.remove("tools")
            val r = post(CLAUDE_URL, headers, body, 20000)
            code = r.first
            text = r.second
        }
        errorMessage(code)?.let { return it }

        val content = JSONObject(text).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val block = content.getJSONObject(i)
            if (block.optString("type") == "text") sb.append(block.optString("text"))
        }
        val answer = sb.toString().trim()
        if (answer.isEmpty()) return "Відповідь порожня. Спробуйте ще раз."
        remember(question, answer)
        return answer
    }

    // ---------- Gemini (безкоштовний рівень) ----------

    private fun requestGemini(question: String): String {
        val contents = JSONArray()
        val snapshot = synchronized(history) { history.toList() }
        for ((role, text) in snapshot) {
            contents.put(
                JSONObject()
                    .put("role", if (role == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        contents.put(
            JSONObject()
                .put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", question)))
        )

        val body = JSONObject()
            .put(
                "system_instruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system())))
            )
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("maxOutputTokens", 500))

        val key = storage.apiKey
        var code = 0
        var text = ""
        val search = needsSearch(question)
        // Без пошуку відповідь приходить за 1-2 с; з пошуком Google довше, тому він лише за потреби.
        for (withSearch in if (search) listOf(true, false) else listOf(false)) {
            if (withSearch) {
                body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            } else {
                body.remove("tools")
            }
            val order = if (withSearch) GEMINI_MODELS else GEMINI_MODELS.sortedBy { if (it.contains("lite")) 0 else 1 }
            for (model in order) {
                // "думання" моделі вимикаємо: для розмови воно лише додає секунди
                body.getJSONObject("generationConfig")
                    .put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
                var r = postSafe("$GEMINI_BASE$model:generateContent", key, body, if (withSearch) 25000 else 15000)
                if (r.first == 400) {
                    body.getJSONObject("generationConfig").remove("thinkingConfig")
                    r = postSafe("$GEMINI_BASE$model:generateContent", key, body, if (withSearch) 25000 else 15000)
                }
                code = r.first
                text = r.second
                if (code in 200..299) break
                if (code == 401 || code == 403) break
                if (code == 400) break
            }
            if (code in 200..299 || code == 401 || code == 403) break
        }
        if (code !in 200..299) logDetails("Gemini", code, text)
        errorMessage(code)?.let { return it }

        val parts = JSONObject(text)
            .optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        }
        val answer = sb.toString().trim()
        if (answer.isEmpty()) return "Відповідь порожня. Спробуйте переформулювати запитання."
        remember(question, answer)
        return answer
    }

    // ---------- окремі завдання: малюнки, документи, математика ----------

    /**
     * Одноразовий запит без історії розмови. file = (mime, байти) для PDF і зображень.
     * callback(текст, помилка) викликається в головному потоці.
     */
    fun generate(
        system: String,
        user: String,
        maxTokens: Int,
        file: Pair<String, ByteArray>? = null,
        callback: (String?, String?) -> Unit
    ) {
        Thread {
            var text: String? = null
            var err: String? = null
            try {
                val r = if (storage.apiKey.startsWith("sk-ant-")) {
                    generateClaude(system, user, maxTokens, file)
                } else {
                    generateGemini(system, user, maxTokens, file)
                }
                text = r.first
                err = r.second
            } catch (e: Exception) {
                err = "Не вдалося отримати відповідь. Перевірте інтернет і ключ."
            }
            mainHandler.post { callback(text, err) }
        }.start()
    }

    private fun generateClaude(
        system: String, user: String, maxTokens: Int, file: Pair<String, ByteArray>?
    ): Pair<String?, String?> {
        val content = JSONArray()
        if (file != null) {
            val b64 = android.util.Base64.encodeToString(file.second, android.util.Base64.NO_WRAP)
            val type = if (file.first == "application/pdf") "document" else "image"
            content.put(
                JSONObject().put("type", type).put(
                    "source",
                    JSONObject().put("type", "base64").put("media_type", file.first).put("data", b64)
                )
            )
        }
        content.put(JSONObject().put("type", "text").put("text", user))
        val body = JSONObject()
            .put("model", CLAUDE_MODEL)
            .put("max_tokens", maxTokens)
            .put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val (code, text) = post(
            CLAUDE_URL,
            mapOf("x-api-key" to storage.apiKey, "anthropic-version" to "2023-06-01"),
            body, 120000
        )
        errorMessage(code)?.let { return null to it }
        val arr = JSONObject(text).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val b = arr.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.optString("text"))
        }
        val out = sb.toString().trim()
        return if (out.isEmpty()) null to "Відповідь порожня. Спробуйте ще раз." else out to null
    }

    private fun generateGemini(
        system: String, user: String, maxTokens: Int, file: Pair<String, ByteArray>?
    ): Pair<String?, String?> {
        val parts = JSONArray()
        if (file != null) {
            val b64 = android.util.Base64.encodeToString(file.second, android.util.Base64.NO_WRAP)
            parts.put(
                JSONObject().put(
                    "inline_data", JSONObject().put("mime_type", file.first).put("data", b64)
                )
            )
        }
        parts.put(JSONObject().put("text", user))
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("maxOutputTokens", maxTokens))
        var code = 0
        var text = ""
        for (model in GEMINI_MODELS) {
            val r = post("$GEMINI_BASE$model:generateContent", mapOf("x-goog-api-key" to storage.apiKey), body, 120000)
            code = r.first
            text = r.second
            if (code in 200..299) break
            if (code == 400 || code == 401 || code == 403) break
        }
        if (code !in 200..299) logDetails("Gemini", code, text)
        errorMessage(code)?.let { return null to it }
        val ps = JSONObject(text).optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (ps != null) for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text"))
        val out = sb.toString().trim()
        return if (out.isEmpty()) null to "Відповідь порожня. Спробуйте переформулювати." else out to null
    }

    fun languageName(): String = Languages.find(storage.ttsLang).adjective
}
