package ua.helper.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.ContactsContract
import android.provider.Settings
import android.view.KeyEvent
import java.util.Locale

/** Керування телефоном: програми, дзвінки, повідомлення, ліхтарик, гучність, музика. */
class PhoneActions(private val context: Context) {

    /** Дія, що чекає підтвердження голосом («так»/«ні»). */
    var pending: (() -> String)? = null

    /** Наступна фраза користувача піде в цю дію (наприклад, текст повідомлення). */
    var pendingInput: ((String) -> String)? = null

    private val uk = Locale("uk", "UA")

    private val aliases: Map<String, List<String>> = mapOf(
        "вайбер" to listOf("viber"),
        "ютуб" to listOf("youtube"),
        "телеграм" to listOf("telegram"),
        "ватсап" to listOf("whatsapp"),
        "вотсап" to listOf("whatsapp"),
        "інстаграм" to listOf("instagram"),
        "фейсбук" to listOf("facebook"),
        "тікток" to listOf("tiktok"),
        "карти" to listOf("maps"),
        "мапи" to listOf("maps"),
        "камера" to listOf("camera"),
        "галерея" to listOf("photos", "gallery"),
        "фото" to listOf("photos", "gallery"),
        "хром" to listOf("chrome"),
        "браузер" to listOf("chrome", "browser"),
        "пошта" to listOf("gmail", "mail"),
        "календар" to listOf("calendar"),
        "годинник" to listOf("clock"),
        "калькулятор" to listOf("calculator"),
        "налаштування" to listOf("settings"),
        "спотіфай" to listOf("spotify"),
        "музика" to listOf("music", "spotify"),
        "телефон" to listOf("dialer", "phone"),
        "контакти" to listOf("contacts"),
        "повідомлення" to listOf("messaging", "messages"),
        "диск" to listOf("drive"),
        "чатгпт" to listOf("chatgpt"),
        "чат джіпіті" to listOf("chatgpt"),
        "радіо" to listOf("radio"),
        "радіоплеєр" to listOf("radio"),
        "месенджер" to listOf("messenger", "orca"),
        "мессенджер" to listOf("messenger", "orca"),
        "ем ікс плеєр" to listOf("mx"),
        "плеєр" to listOf("mx", "player"),
        "тікток" to listOf("tiktok"),
        "тривога" to listOf("тривог", "повітряна"),
        "гугл мапс" to listOf("maps"),
        "гугл карти" to listOf("maps"),
        "файли" to listOf("files"),
        "приват" to listOf("privat"),
        "моно" to listOf("mono")
    )

    private fun hasPerm(p: String) =
        context.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun cleanup(t: String, junk: List<String>): String {
        var s = " $t "
        for (w in junk) s = s.replace(" $w ", " ")
        return s.trim().replace(Regex("\\s+"), " ")
    }

    // ---------- програми ----------

    fun openApp(t: String): String {
        val name = cleanup(
            t,
            listOf("відкрий", "відкрити", "запусти", "запустити", "програму", "додаток", "застосунок", "мені", "будь ласка")
        )
        if (name.isEmpty()) return "Яку програму відкрити?"

        val pm = context.packageManager
        val allowed = Storage(context).allowedApps
        val hit = resolveApp(name) ?: return if (allowed != null) {
            "Не знайшов програму «$name» серед дозволених. Дозволити її можна в налаштуваннях."
        } else {
            "Не знайшов програму «$name»."
        }

        val label = hit.loadLabel(pm).toString()
        val intent = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?: return "Не вдалося відкрити «$label»."
        Launcher.start(context, intent, "Відкрити $label")
        return "Відкриваю $label."
    }

    @Suppress("DEPRECATION")
    private fun resolveApp(name: String): android.content.pm.ResolveInfo? {
        val pm = context.packageManager
        val allowed = Storage(context).allowedApps
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .filter { allowed == null || it.activityInfo.packageName in allowed }
        val keys = mutableListOf(name)
        if (name.length >= 5) keys.add(name.dropLast(2))
        for ((k, v) in aliases) {
            if (name == k || name.startsWith(k.dropLast(1))) keys.addAll(v)
        }
        return apps.firstOrNull { ri ->
            val label = ri.loadLabel(pm).toString().lowercase(uk)
            val pkg = ri.activityInfo.packageName.lowercase(uk)
            keys.any { label.contains(it) || pkg.contains(it) }
        }
    }

    private fun appPackageAllowed(pkgPart: String): Boolean {
        val allowed = Storage(context).allowedApps ?: return true
        return allowed.any { it.contains(pkgPart) }
    }

    private fun isInstalled(pkg: String): Boolean = try {
        context.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    /** Шукає в фразі «у вайбері», «через телеграм», «в контактах» тощо. Повертає (програма, фрагмент). */
    private fun findAppMention(s: String): Pair<String, String>? {
        val re = Regex("(?:^| )(?:в|у|через|по|на|з|із) ([а-яіїєґa-z\\-]{4,})")
        for (m in re.findAll(s)) {
            val w = m.groupValues[1]
            if (w.startsWith("контакт")) return "контакти" to m.value
            for ((k, _) in aliases) {
                if (w.startsWith(k.dropLast(1)) && k != "контакти") return k to m.value
            }
        }
        return null
    }

    /** Відкриває картку контакту в програмі «Контакти». */
    private fun openContactCard(c: Contact): String {
        val uri = android.content.ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, c.id)
        Launcher.start(context, Intent(Intent.ACTION_VIEW, uri), "Контакт: ${c.name}")
        return "Відкриваю контакт ${c.name}."
    }

    /** Прямий дзвінок через Viber або WhatsApp за рядком даних контакту. */
    private fun callViaMessenger(c: Contact, pkg: String, mime: String, label: String): String? {
        if (!isInstalled(pkg)) return "$label не встановлено на телефоні."
        val cur = context.contentResolver.query(
            ContactsContract.Data.CONTENT_URI,
            arrayOf(ContactsContract.Data._ID),
            ContactsContract.Data.CONTACT_ID + "=? AND " + ContactsContract.Data.MIMETYPE + "=?",
            arrayOf(c.id.toString(), mime),
            null
        )
        var dataId = -1L
        cur?.use { if (it.moveToFirst()) dataId = it.getLong(0) }
        if (dataId < 0) return null
        val uri = Uri.parse("content://com.android.contacts/data/$dataId")
        Launcher.start(context, Intent(Intent.ACTION_VIEW, uri).setPackage(pkg), "$label: ${c.name}")
        return "Дзвоню через $label: ${c.name}."
    }

    // ---------- контакти ----------

    private class Contact(val name: String, val number: String, val id: Long)

    private fun commonPrefix(a: String, b: String): Int {
        var i = 0
        while (i < a.length && i < b.length && a[i] == b[i]) i++
        return i
    }

    /** Порівнюємо слова за початком, щоб «мамі», «мамо» знаходили контакт «Мама». */
    private fun score(spokenWords: List<String>, name: String): Int {
        var best = 0
        for (nw in name.split(" ", "-", ".")) {
            if (nw.length < 3) continue
            for (sw in spokenWords) {
                val p = commonPrefix(sw, nw)
                if (p >= maxOf(3, minOf(sw.length, nw.length) - 2) && p > best) best = p
            }
        }
        return best
    }

    private fun findContact(spoken: String): Contact? {
        val words = spoken.lowercase(uk).split(" ").filter { it.length >= 3 }
        if (words.isEmpty()) return null
        var best: Contact? = null
        var bestScore = 0
        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID
            ),
            null, null, null
        ) ?: return null
        cursor.use {
            while (it.moveToNext()) {
                val name = it.getString(0) ?: continue
                val number = it.getString(1) ?: continue
                val s = score(words, name.lowercase(uk))
                if (s > bestScore) {
                    bestScore = s
                    best = Contact(name, number, it.getLong(2))
                }
            }
        }
        return best
    }

    private val needContacts =
        "Щоб працювати з контактами, відкрийте Арчіка й натисніть «Дозволити контакти й дзвінки»."

    fun call(t: String): String {
        var s = cleanup(
            t,
            listOf(
                "подзвони", "подзвонити", "зателефонуй", "зателефонувати", "телефонуй",
                "набери", "мені", "будь ласка", "на номер", "з моїх контактів", "з контактів",
                "із моїх контактів", "із контактів", "з телефонної книги", "контакту", "контакт",
                "номер", "номера"
            )
        )
        if (s.isEmpty()) return "Кому подзвонити?"

        // чи назвав користувач програму: «у вайбері», «через телеграм», «в контактах»
        val mention = findAppMention(s)
        val app = mention?.first
        if (mention != null) s = cleanup(s, listOf(mention.second.trim()))
        if (s.isEmpty()) {
            return if (app != null) openApp("відкрий $app") else "Кому подзвонити?"
        }

        val digits = s.filter { it.isDigit() }
        val byNumber = digits.length >= 7
        var contact: Contact? = null
        if (!byNumber) {
            if (!hasPerm(Manifest.permission.READ_CONTACTS)) return needContacts
            contact = findContact(s) ?: return "Не знайшов у контактах «$s»."
        }
        val number = if (byNumber) digits else contact!!.number
        val display = if (byNumber) digits else contact!!.name

        when (app) {
            "контакти" -> {
                if (contact != null) return openContactCard(contact)
                return openApp("відкрий контакти")
            }
            "вайбер" -> {
                if (!appPackageAllowed("viber")) return "Вайбер не додано до дозволених програм."
                if (contact != null) {
                    callViaMessenger(contact, "com.viber.voip", "vnd.android.cursor.item/vnd.com.viber.voip.viber_number_call", "Viber")
                        ?.let { return it }
                }
                val intl = if (number.length == 10 && number.startsWith("0")) "38$number" else number
                Launcher.start(context, Intent(Intent.ACTION_VIEW, Uri.parse("viber://chat?number=$intl")), "Viber: $display")
                return "Відкриваю Viber: $display. Натисніть дзвінок."
            }
            "ватсап", "вотсап" -> {
                if (!appPackageAllowed("whatsapp")) return "WhatsApp не додано до дозволених програм."
                if (contact != null) {
                    callViaMessenger(contact, "com.whatsapp", "vnd.android.cursor.item/vnd.com.whatsapp.voip.call", "WhatsApp")
                        ?.let { return it }
                }
                val intl = if (number.length == 10 && number.startsWith("0")) "38$number" else number
                Launcher.start(context, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$intl")), "WhatsApp: $display")
                return "Відкриваю WhatsApp: $display."
            }
            "телеграм" -> {
                if (!appPackageAllowed("telegram")) return "Телеграм не додано до дозволених програм."
                val intl = if (number.length == 10 && number.startsWith("0")) "38$number" else number
                Launcher.start(context, Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?phone=$intl")), "Telegram: $display")
                return "Відкриваю Telegram: $display."
            }
            null, "телефон" -> {}
            else -> return openApp("відкрий $app")
        }
        val action = if (hasPerm(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        Launcher.start(context, Intent(action, Uri.parse("tel:" + Uri.encode(number))), "Подзвонити: $display")
        return "Дзвоню: $display."
    }

    fun message(t: String): String {
        val other = findAppMention(t)?.first
        if (other == "ватсап" || other == "вотсап" || other == "телеграм") {
            return messageViaOther(t, other)
        }
        val viberNamed = t.contains("вайбер")
        val smsNamed = t.contains("смс") || t.contains("sms") || t.contains("есемес")
        if (viberNamed && !appPackageAllowed("viber")) {
            return "Вайбер не додано до дозволених програм. Дозвольте його в налаштуваннях."
        }
        val s = cleanup(
            t,
            listOf(
                "напиши", "написати", "відправ", "відправити", "надішли", "надіслати",
                "повідомлення", "смс", "sms", "есемес", "в вайбері", "у вайбері",
                "через вайбер", "в вайбер", "у вайбер", "вайбері", "вайбер",
                "мені", "будь ласка", "листа"
            )
        )
        if (s.isEmpty()) return "Кому написати?"
        if (!hasPerm(Manifest.permission.READ_CONTACTS)) return needContacts

        val words = s.split(" ")
        var contact: Contact? = null
        var used = 0
        for (n in 1..minOf(2, words.size)) {
            val c = findContact(words.take(n).joinToString(" "))
            if (c != null) {
                contact = c
                used = n
                break
            }
        }
        val c = contact ?: return "Не знайшов у контактах «${words[0]}»."

        val text = words.drop(used).joinToString(" ").trim()
            .replace(Regex("^(що|текст)\\s+"), "")
            .replaceFirstChar { it.uppercase() }
        val useViber = viberNamed ||
            (!smsNamed && isInstalled("com.viber.voip") && appPackageAllowed("viber"))

        if (text.isEmpty()) {
            pendingInput = { reply ->
                deliver(c, reply.trim().replaceFirstChar { it.uppercase() }, useViber, true)
            }
            return "Що передати: ${c.name}?"
        }
        return deliver(c, text, useViber, Storage(context).driveMode)
    }

    private fun deliver(c: Contact, text: String, viber: Boolean, confirm: Boolean): String {
        if (confirm && text.isNotEmpty()) {
            pending = { doDeliver(c, text, viber) }
            return "Надіслати ${c.name} у ${if (viber) "Viber" else "SMS"}: $text? Скажіть так або ні."
        }
        return doDeliver(c, text, viber)
    }

    private fun doDeliver(c: Contact, text: String, viber: Boolean): String {
        if (!viber && text.isNotEmpty() && Storage(context).driveMode && hasPerm(Manifest.permission.SEND_SMS)) {
            return try {
                @Suppress("DEPRECATION")
                val sm = android.telephony.SmsManager.getDefault()
                sm.sendMultipartTextMessage(c.number, null, sm.divideMessage(text), null, null)
                "Повідомлення для ${c.name} надіслано."
            } catch (e: Exception) {
                "Не вдалося надіслати повідомлення."
            }
        }
        val digits = c.number.filter { it.isDigit() }
        val intent = if (viber) {
            val intl = if (digits.length == 10 && digits.startsWith("0")) "38$digits" else digits
            var uri = "viber://chat?number=$intl"
            if (text.isNotEmpty()) uri += "&draft=" + Uri.encode(text)
            Intent(Intent.ACTION_VIEW, Uri.parse(uri))
        } else {
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(c.number)))
                .putExtra("sms_body", text)
        }
        Launcher.start(context, intent, "Повідомлення: ${c.name}")
        return if (text.isEmpty()) {
            "Відкриваю чат з ${c.name}."
        } else if (viber) {
            "Повідомлення для ${c.name} готове у Viber. Натисніть «Надіслати» на екрані."
        } else {
            "Повідомлення для ${c.name} готове. Натисніть «Надіслати» на екрані."
        }
    }

    private fun messageViaOther(t: String, app: String): String {
        if (!hasPerm(Manifest.permission.READ_CONTACTS)) return needContacts
        val s = cleanup(
            t,
            listOf("напиши", "написати", "відправ", "відправити", "надішли", "надіслати", "повідомлення",
                "в ватсапі", "у ватсапі", "в вотсапі", "у вотсапі", "в телеграмі", "у телеграмі", "в телеграм",
                "у телеграм", "через ватсап", "через вотсап", "через телеграм", "мені", "будь ласка")
        )
        val words = s.split(" ").filter { it.isNotEmpty() }
        if (words.isEmpty()) return "Кому написати?"
        var contact: Contact? = null
        var used = 0
        for (n in 1..minOf(2, words.size)) {
            val c = findContact(words.take(n).joinToString(" "))
            if (c != null) {
                contact = c
                used = n
                break
            }
        }
        val c = contact ?: return "Не знайшов у контактах «${words[0]}»."
        val text = words.drop(used).joinToString(" ").replace(Regex("^(що|текст)\\s+"), "")
            .replaceFirstChar { it.uppercase() }
        val d = c.number.filter { it.isDigit() }
        val intl = if (d.length == 10 && d.startsWith("0")) "38$d" else d
        val uri = if (app == "телеграм") "tg://resolve?phone=$intl"
        else "https://wa.me/$intl" + if (text.isNotEmpty()) "?text=" + Uri.encode(text) else ""
        Launcher.start(context, Intent(Intent.ACTION_VIEW, Uri.parse(uri)), "Повідомлення: ${c.name}")
        return "Відкриваю чат з ${c.name}."
    }

    // ---------- керування дзвінками ----------

    fun answerCall(): String {
        if (!hasPerm(Manifest.permission.ANSWER_PHONE_CALLS)) {
            return "Потрібен дозвіл на керування дзвінками. Дайте його в налаштуваннях Арчіка."
        }
        val tm = context.getSystemService(Context.TELECOM_SERVICE) as android.telecom.TelecomManager
        return try {
            tm.acceptRingingCall()
            CallState.ringing = false
            "Піднімаю слухавку."
        } catch (e: SecurityException) {
            "Не вдалося підняти слухавку: немає дозволу."
        }
    }

    fun endCall(): String {
        if (Build.VERSION.SDK_INT < 28) return "Завершувати дзвінки голосом можна на Android 9 і новіших."
        if (!hasPerm(Manifest.permission.ANSWER_PHONE_CALLS)) {
            return "Потрібен дозвіл на керування дзвінками. Дайте його в налаштуваннях Арчіка."
        }
        val tm = context.getSystemService(Context.TELECOM_SERVICE) as android.telecom.TelecomManager
        return try {
            val ok = tm.endCall()
            CallState.ringing = false
            if (ok) "Завершую дзвінок." else "Зараз немає активного дзвінка."
        } catch (e: SecurityException) {
            "Не вдалося завершити дзвінок: немає дозволу."
        }
    }

    // ---------- ліхтарик, гучність, музика ----------

    fun torch(on: Boolean): String {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "На цьому телефоні немає ліхтарика."
            cm.setTorchMode(id, on)
            if (on) "Ліхтарик увімкнено." else "Ліхтарик вимкнено."
        } catch (e: Exception) {
            "Не вдалося керувати ліхтариком."
        }
    }

    fun volume(t: String): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val flag = AudioManager.FLAG_SHOW_UI
        val pct = Regex("(\\d{1,3}) ?(відсотк\\S*|%)").find(t)
        return when {
            pct != null -> {
                val p = pct.groupValues[1].toInt().coerceIn(0, 100)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(max * p / 100.0).toInt(), flag)
                "Гучність $p відсотків."
            }
            t.contains("максимум") || t.contains("максимальн") || t.contains("на повну") -> {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, max, flag)
                "Гучність на максимум."
            }
            t.contains("мінімум") || t.contains("мінімальн") -> {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, 1, flag)
                "Гучність на мінімум."
            }
            t.contains("вимкни звук") || t.contains("без звуку") -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, flag)
                "Звук вимкнено."
            }
            t.contains("увімкни звук") -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, flag)
                "Звук увімкнено."
            }
            t.contains("тихіш") || t.contains("зменш") -> {
                repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, flag) }
                "Зробив тихіше."
            }
            t.contains("гучніш") || t.contains("голосніш") || t.contains("збільш") || t.contains("підніми") -> {
                repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, flag) }
                "Зробив гучніше."
            }
            else -> "Скажіть: гучніше, тихіше або гучність 50 відсотків."
        }
    }

    /** Керування музикою в будь-якому плеєрі. Повертає null, якщо це не команда для музики. */
    fun media(t: String): String? {
        val song = t.contains("пісн") || t.contains("трек") || t.contains("композиц") || t.contains("музик")
        // «увімкни пісню Океан Ельзи», «увімкни музику Скрябін», «увімкни в ютубі ...»
        val play = Regex("^(?:увімкни|включи|заграй|пусти|постав|грай)(?: мені)? (?:пісню|пісні|трек|музику|композицію)? ?(.+)$").find(t)
        if (play != null && !t.contains("наступн") && !t.contains("попередн")) {
            val onYoutube = t.contains("ютуб") || t.contains("youtube")
            val q = play.groupValues[1]
                .replace(Regex("^(?:в|у|на) (?:ютубі|ютуб|youtube|спотіфай|спотіфаї) "), "")
                .replace(Regex(" (?:в|у|на) (?:ютубі|ютуб|youtube)$"), "")
                .trim()
            if (q.length >= 3 && q !in setOf("музику", "пісню", "музика") && !Regex("^(ліхтар|вайфай|блютуз|звук|гучн|світло|на пауз|навігац|режим|будильник|таймер|нагадуван|інтернет|мобільн|екран)").containsMatchIn(q)) {
                if (onYoutube) {
                    openYoutubeSearch(q)
                    return "Шукаю на YouTube: $q."
                }
                if (!LocalMusic.hasPermission(context)) {
                    return "Щоб вмикати музику з телефону, дайте доступ до музики в налаштуваннях Арчіка. " +
                        "Поки що можу знайти її на YouTube: скажіть «увімкни $q на ютубі»."
                }
                val found = LocalMusic.search(context, q)
                if (found.isNotEmpty()) {
                    LocalMusic.play(context, found)
                    val cur = LocalMusic.current()
                    return if (found.size == 1) "Вмикаю: ${cur?.artist} ${cur?.title}."
                    else "Знайшов ${found.size} композицій. Вмикаю: ${cur?.artist} ${cur?.title}."
                }
                if (true) {
                    openYoutubeSearch(q)
                    return "У файлах телефону не знайшов «$q». Шукаю на YouTube."
                }
                val i = Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                    .putExtra(android.app.SearchManager.QUERY, q)
                    .putExtra(android.provider.MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                val ok = i.resolveActivity(context.packageManager) != null
                if (ok) {
                    Launcher.start(context, i, "Музика: $q")
                } else {
                    openYoutubeSearch(q)
                }
                return "Вмикаю: $q."
            }
        }
        val key = when {
            t.contains("наступн") && song || t == "далі" || t.contains("перемкни") && song || t.contains("пропусти") && song ->
                KeyEvent.KEYCODE_MEDIA_NEXT
            t.contains("попередн") && song || t.contains("поверни") && song ->
                KeyEvent.KEYCODE_MEDIA_PREVIOUS
            t.contains("пауза") || t.contains("паузу") || t.contains("зупини музику") ||
                t.contains("вимкни музику") || t.contains("зупини пісню") || t.contains("постав на паузу") ||
                t.contains("тиша музика") -> KeyEvent.KEYCODE_MEDIA_PAUSE
            t.contains("увімкни музику") || t.contains("включи музику") || t.contains("грай музику") ||
                t.contains("продовж музику") || t.contains("продовжуй музику") || t.contains("продовж пісню") ||
                t == "грай" || t == "продовжуй" -> KeyEvent.KEYCODE_MEDIA_PLAY
            else -> return null
        }
        if (LocalMusic.active) {
            when (key) {
                KeyEvent.KEYCODE_MEDIA_NEXT -> {
                    LocalMusic.next(context)
                    val c = LocalMusic.current()
                    return "Наступна: ${c?.artist} ${c?.title}."
                }
                KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    LocalMusic.previous(context)
                    val c = LocalMusic.current()
                    return "Попередня: ${c?.artist} ${c?.title}."
                }
                KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                    LocalMusic.pause()
                    return "Пауза."
                }
                else -> {
                    LocalMusic.resume()
                    return "Граю."
                }
            }
        }
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
        return when (key) {
            KeyEvent.KEYCODE_MEDIA_NEXT -> "Наступна."
            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> "Попередня."
            KeyEvent.KEYCODE_MEDIA_PAUSE -> "Пауза."
            else -> "Граю."
        }
    }

    // ---------- налаштування, батарея, навігація, пошук ----------

    fun wifi(): String {
        val i = if (Build.VERSION.SDK_INT >= 29) {
            Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
        } else {
            Intent(Settings.ACTION_WIFI_SETTINGS)
        }
        Launcher.start(context, i, "Налаштування Wi-Fi")
        return "Android не дозволяє програмам вмикати Wi-Fi самостійно. Відкриваю панель, натисніть перемикач."
    }

    fun bluetooth(): String {
        Launcher.start(context, Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "Налаштування Bluetooth")
        return "Android не дозволяє програмам вмикати Bluetooth самостійно. Відкриваю налаштування."
    }

    fun battery(): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val p = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return "Заряд батареї $p відсотків."
    }

    fun navigate(t: String): String {
        var place = cleanup(
            t,
            listOf("прокладі", "проклади", "маршрут", "навігація", "навігацію", "як", "доїхати", "до", "мені",
                "будь ласка", "увімкни", "покажи", "дорогу", "поїхати", "їхати", "веди")
        )
        if (place.isEmpty()) return "Куди їхати?"
        if (place == "додому" || place == "дім" || place == "в дім" || place == "до дому") {
            val home = Storage(context).homeAddress
            if (home.isBlank()) return "Я не знаю вашої домашньої адреси. Скажіть: запам'ятай домашню адресу, і назвіть її."
            place = home
        }
        Launcher.start(
            context,
            Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place))).also {
                if (isInstalled("com.google.android.apps.maps")) it.setPackage("com.google.android.apps.maps")
            },
            "Навігація: $place"
        )
        return "Прокладаю маршрут: $place."
    }

    fun nearby(t: String): String {
        val q = cleanup(
            t,
            listOf("знайди", "найближчу", "найближчий", "найближче", "найближчі", "найближча", "найближчого",
                "покажи", "де", "є", "мені", "будь ласка", "тут", "поряд")
        )
        if (q.isEmpty()) return "Що шукати поруч?"
        Launcher.start(
            context,
            Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))),
            "Поруч: $q"
        )
        return "Шукаю на карті поруч: $q."
    }

    fun youtube(t: String): String {
        val q = cleanup(
            t,
            listOf("знайди", "покажи", "відео", "відос", "про", "на", "в", "у", "ютубі", "ютуб", "youtube", "мені", "будь ласка")
        )
        if (q.isEmpty()) return "Яке відео знайти?"
        openYoutubeSearch(q)
        return "Шукаю на YouTube: $q."
    }

    private fun openYoutubeSearch(q: String) {
        val i = if (isInstalled("com.google.android.youtube")) {
            Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q)
        } else {
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))
        }
        Launcher.start(context, i, "YouTube: $q")
    }

    /** Грає всю музику з телефону (у випадковому порядку). */
    fun playMyMusic(): String {
        if (!LocalMusic.hasPermission(context)) {
            return "Щоб вмикати музику з телефону, дайте доступ до музики в налаштуваннях Арчіка."
        }
        val all = LocalMusic.all(context)
        if (all.isEmpty()) return "У телефоні не знайшов музичних файлів."
        LocalMusic.play(context, all)
        val c = LocalMusic.current()
        return "Вмикаю вашу музику: ${c?.artist} ${c?.title}."
    }

    fun openAlertApp(): String {
        val hit = resolveApp("тривога")
            ?: return "Програму «Тривога» не знайшов серед встановлених або дозволених. Встановіть її або дозвольте в налаштуваннях Арчіка."
        val label = hit.loadLabel(context.packageManager).toString()
        val i = context.packageManager.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?: return "Не вдалося відкрити «$label»."
        Launcher.start(context, i, "Відкрити $label")
        return "Відкриваю $label."
    }

    fun openMaps(): String {
        val pkg = "com.google.android.apps.maps"
        if (!isInstalled(pkg)) return "Google Maps не встановлено на телефоні."
        if (!appPackageAllowed("maps")) return "Карти не додано до дозволених програм."
        val i = context.packageManager.getLaunchIntentForPackage(pkg)
            ?: return "Не вдалося відкрити Google Maps."
        Launcher.start(context, i, "Google Maps")
        return "Відкриваю карти."
    }

    @Suppress("DEPRECATION")
    fun unlock(): String {
        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            val wl = pm.newWakeLock(
                android.os.PowerManager.FULL_WAKE_LOCK or android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP or
                    android.os.PowerManager.ON_AFTER_RELEASE,
                "assistant:screen"
            )
            wl.acquire(5000)
        } catch (e: Exception) {
            // спробуємо через екран
        }
        Launcher.start(context, Intent(context, WakeActivity::class.java), "Розблокувати телефон")
        return "Вмикаю екран. Розблокуйте телефон PIN-кодом, ключем або відбитком: обійти захист я не можу."
    }

    fun openMusicApp(): String {
        val hit = resolveApp("музика")
        val pm = context.packageManager
        val intent = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
            ?: Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)
        Launcher.start(context, intent, "Музика")
        return "Відкриваю музику."
    }

    fun callLog(): String {
        Launcher.start(context, Intent(Intent.ACTION_VIEW).setType(android.provider.CallLog.Calls.CONTENT_TYPE), "Журнал викликів")
        return "Відкриваю журнал викликів."
    }

    fun redial(): String {
        if (!hasPerm(Manifest.permission.READ_CALL_LOG)) {
            return "Щоб повторити останній дзвінок, дозвольте доступ до журналу викликів у налаштуваннях Арчіка."
        }
        val number = android.provider.CallLog.Calls.getLastOutgoingCall(context)
        if (number.isNullOrBlank()) return "Журнал вихідних дзвінків порожній."
        val action = if (hasPerm(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        Launcher.start(context, Intent(action, Uri.parse("tel:" + Uri.encode(number))), "Подзвонити: $number")
        return "Дзвоню на останній набраний номер."
    }

    fun speaker(on: Boolean): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                if (on) {
                    am.availableCommunicationDevices
                        .firstOrNull { it.type == android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                        ?.let { am.setCommunicationDevice(it) }
                } else {
                    am.clearCommunicationDevice()
                }
            } else {
                @Suppress("DEPRECATION")
                am.isSpeakerphoneOn = on
            }
        } catch (e: Exception) {
            // нижче скажемо про обмеження
        }
        return (if (on) "Спробував увімкнути гучний зв'язок. " else "Спробував вимкнути гучний зв'язок. ") +
            "Якщо звук не змінився, натисніть кнопку динаміка на екрані дзвінка: Android не дозволяє сторонім програмам керувати цим під час розмови."
    }

    fun camera(photo: Boolean): String {
        val i = Intent(if (photo) android.provider.MediaStore.ACTION_IMAGE_CAPTURE else android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        Launcher.start(context, i, "Камера")
        return if (photo) "Відкриваю камеру. Натисніть кнопку затвора." else "Відкриваю камеру."
    }

    fun downloads(): String {
        Launcher.start(context, Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS), "Завантаження")
        return "Відкриваю завантаження."
    }

    fun search(t: String): String {
        val q = cleanup(
            t,
            listOf("загугли", "погугли", "нагугли", "знайди", "пошукай", "в інтернеті", "в гуглі", "мені", "будь ласка")
        )
        if (q.isEmpty()) return "Що знайти?"
        Launcher.start(
            context,
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))),
            "Пошук: $q"
        )
        return "Шукаю в інтернеті: $q."
    }
}
