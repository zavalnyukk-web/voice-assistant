package ua.helper.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.Outline
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.ImageView

/** Сяюче кільце навколо аватара. */
class GlowRing(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = Ui.dp(context, 3).toFloat()
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = Ui.dp(context, 8).toFloat()
        color = Color.argb(70, 60, 140, 255)
        maskFilter = android.graphics.BlurMaskFilter(Ui.dp(context, 10).toFloat(), android.graphics.BlurMaskFilter.Blur.NORMAL)
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onDraw(canvas: Canvas) {
        val pad = Ui.dp(context, 12).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f - pad
        paint.shader = SweepGradient(
            cx, cy,
            intArrayOf(Color.parseColor("#1E6BFF"), Color.parseColor("#6FD3FF"), Color.parseColor("#1E6BFF")),
            null
        )
        canvas.drawCircle(cx, cy, r, glow)
        canvas.drawCircle(cx, cy, r, paint)
    }
}

/** Анімована звукова хвиля з стовпчиків. */
class WaveView(context: Context) : View(context) {
    var active = false
        set(v) {
            field = v
            invalidate()
        }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#3D8BFF") }
    private val bars = 9
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val gap = w / bars
        val bw = gap * 0.45f
        val t = System.currentTimeMillis() / 220.0
        for (i in 0 until bars) {
            val centerBoost = 1f - kotlin.math.abs(i - (bars - 1) / 2f) / bars
            val amp = if (active) (0.35f + 0.65f * ((Math.sin(t + i * 1.3) + 1) / 2).toFloat()) else 0.18f
            val bh = (h * 0.9f * amp * (0.5f + centerBoost)).coerceAtMost(h)
            val x = gap * i + gap / 2f
            rect.set(x - bw / 2, (h - bh) / 2, x + bw / 2, (h + bh) / 2)
            paint.alpha = if (active) 255 else 110
            canvas.drawRoundRect(rect, bw / 2, bw / 2, paint)
        }
        if (active) postInvalidateOnAnimation()
    }
}

/** Круглий аватар. */
fun circularAvatar(context: Context): ImageView = ImageView(context).apply {
    setImageResource(R.drawable.avatar)
    scaleType = ImageView.ScaleType.CENTER_CROP
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setOval(0, 0, view.width, view.height)
        }
    }
    clipToOutline = true
}
