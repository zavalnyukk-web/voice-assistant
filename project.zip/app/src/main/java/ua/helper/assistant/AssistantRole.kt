package ua.helper.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService

/** Дозволяє зробити Арчіка «цифровим асистентом» телефону, як Google Assistant. */
class ArchikInteractionService : VoiceInteractionService()

class ArchikSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = ArchikSession(this)
}

/** Викликається довгим натисканням кнопки живлення чи жестом асистента: одразу слухаємо команду. */
class ArchikSession(context: Context) : VoiceInteractionSession(context) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        try {
            val i = Intent(context, AssistantService::class.java).setAction(AssistantService.ACTION_LISTEN)
            context.startForegroundService(i)
        } catch (e: Exception) {
            // нічого
        }
        hide()
    }
}

/** Заглушка: потрібна системі для реєстрації асистента, розпізнавання робить Google. */
class ArchikRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        try {
            listener?.error(android.speech.SpeechRecognizer.ERROR_CLIENT)
        } catch (e: Exception) {
        }
    }

    override fun onCancel(listener: Callback?) {}
    override fun onStopListening(listener: Callback?) {}
}
