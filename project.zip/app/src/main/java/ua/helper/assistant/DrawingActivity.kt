package ua.helper.assistant

import android.app.Activity
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Показує намальований ШІ малюнок (SVG) і зберігає його в галерею. */
class DrawingActivity : Activity() {
    private lateinit var web: WebView
    private var title = "малюнок"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        title = intent.getStringExtra("title") ?: "малюнок"
        val svg = try {
            File(intent.getStringExtra("path") ?: "").readText()
        } catch (e: Exception) {
            ""
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            setPadding(Ui.dp(this@DrawingActivity, 14), Ui.dp(this@DrawingActivity, 14), Ui.dp(this@DrawingActivity, 14), Ui.dp(this@DrawingActivity, 14))
        }
        root.addView(TextView(this).apply {
            text = title.replaceFirstChar { it.uppercase() }
            textSize = 20f
            setTextColor(Ui.TEXT)
            typeface = Typeface.DEFAULT_BOLD
        })
        web = WebView(this).apply {
            settings.javaScriptEnabled = false
            settings.blockNetworkLoads = true
            settings.allowFileAccess = false
            setBackgroundColor(Color.WHITE)
            val html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
                "<style>html,body{margin:0;background:#fff}svg{width:100vw;height:100vw;display:block}</style>" +
                "</head><body>$svg</body></html>"
            loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
        }
        val side = resources.displayMetrics.widthPixels - Ui.dp(this, 28)
        root.addView(web, LinearLayout.LayoutParams(side, side).apply { topMargin = Ui.dp(this@DrawingActivity, 12) })

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row.addView(button("Зберегти в галерею", true) { save() })
        row.addView(button("Закрити", false) { finish() })
        root.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = Ui.dp(this@DrawingActivity, 16) })
        setContentView(root)
    }

    private fun button(label: String, primary: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 15f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        background = if (primary) Ui.gradient(this@DrawingActivity, Ui.ACCENT, Color.parseColor("#2563EB"), 24)
        else Ui.rounded(this@DrawingActivity, Ui.SURFACE2, 24)
        setPadding(Ui.dp(this@DrawingActivity, 18), Ui.dp(this@DrawingActivity, 12), Ui.dp(this@DrawingActivity, 18), Ui.dp(this@DrawingActivity, 12))
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(this@DrawingActivity, 6)
            marginEnd = Ui.dp(this@DrawingActivity, 6)
        }
        setOnClickListener { onClick() }
    }

    private fun save() {
        try {
            val w = web.width
            val h = web.height
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            web.draw(Canvas(bmp))
            val name = "Archik_${System.currentTimeMillis()}.png"
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Арчік")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
                    ?: throw RuntimeException("no uri")
                contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                Toast.makeText(this, "Збережено в галерею: Pictures/Арчік", Toast.LENGTH_LONG).show()
            } else {
                val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                val f = File(dir, name)
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                Toast.makeText(this, "Збережено: ${f.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Не вдалося зберегти малюнок.", Toast.LENGTH_LONG).show()
        }
    }
}
