package ua.helper.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Спеціальні можливості: дозволяють Арчіку натискати кнопки й вкладки в інших програмах,
 * гортати екран і натискати «Назад». Вмикаються користувачем у налаштуваннях телефону.
 */
class ArchikAccess : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ArchikAccess? = null

        fun enabled() = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun clickableParent(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var cur: AccessibilityNodeInfo? = n
        var depth = 0
        while (cur != null && depth < 8) {
            if (cur.isClickable) return cur
            cur = cur.parent
            depth++
        }
        return null
    }

    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val variants = mutableListOf(text)
        if (text.length >= 5) variants.add(text.dropLast(1))
        if (text.length >= 6) variants.add(text.dropLast(2))
        for (v in variants) {
            val nodes = root.findAccessibilityNodeInfosByText(v)
            if (nodes.isNullOrEmpty()) continue
            val exact = nodes.firstOrNull {
                (it.text?.toString() ?: it.contentDescription?.toString() ?: "").trim().equals(text, true)
            }
            val ordered = if (exact != null) listOf(exact) + nodes.filter { it != exact } else nodes
            for (n in ordered) {
                val target = clickableParent(n)
                if (target != null && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
        }
        return false
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        while (stack.isNotEmpty()) {
            val n = stack.removeFirst()
            if (n.isScrollable) {
                return n.performAction(
                    if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                )
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.add(it) }
        }
        return false
    }

    fun global(action: Int): Boolean = performGlobalAction(action)
}
